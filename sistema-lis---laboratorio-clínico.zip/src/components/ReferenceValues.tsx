/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Plus, 
  Edit, 
  Search, 
  Trash, 
  Save, 
  X, 
  Info 
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { ReferenceRange, Exam } from '../types/lis';

interface ReferenceValuesProps {
  referenceRanges: ReferenceRange[];
  exams: Exam[];
  onUpdateRanges: (ranges: ReferenceRange[]) => void;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function ReferenceValues({ 
  referenceRanges, 
  exams, 
  onUpdateRanges,
  onAddAuditLog
}: ReferenceValuesProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSexFilter, setSelectedSexFilter] = useState<'Todos' | 'M' | 'F' | 'Todos_Filtro'>('Todos_Filtro');
  const [editingRange, setEditingRange] = useState<ReferenceRange | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  // New Range form state
  const [newRange, setNewRange] = useState<Omit<ReferenceRange, 'id'>>({
    examCode: exams[0]?.code || '',
    ageMin: 0,
    ageMax: 120,
    sex: 'Todos',
    unit: 'mg/dL',
    valMin: 0,
    valMax: 100,
    textReference: '',
    observations: ''
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter ranges
  const filteredRanges = referenceRanges.filter(range => {
    const exam = exams.find(e => e.code === range.examCode);
    const examName = exam ? exam.name.toLowerCase() : '';
    const examCodeLower = range.examCode.toLowerCase();
    const query = searchQuery.toLowerCase();

    const matchesSearch = examName.includes(query) || examCodeLower.includes(query);
    const matchesSex = selectedSexFilter === 'Todos_Filtro' || range.sex === selectedSexFilter;

    return matchesSearch && matchesSex;
  });

  // Create Range manually
  const handleAddRange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRange.examCode) {
      alert('Por favor seleccione un examen para asociar este rango.');
      return;
    }

    const nextId = `REF-${String(Math.floor(1000 + Math.random() * 9000))}`;
    const created: ReferenceRange = {
      id: nextId,
      ...newRange,
      valMin: newRange.valMin === null || isNaN(newRange.valMin) ? null : Number(newRange.valMin),
      valMax: newRange.valMax === null || isNaN(newRange.valMax) ? null : Number(newRange.valMax),
    };

    const updatedList = [...referenceRanges, created];
    onUpdateRanges(updatedList);
    onAddAuditLog('Valores Referencia - Agregar', `Agregó un nuevo rango para examen ${created.examCode} (ID: ${created.id})`);
    
    // reset
    setNewRange({
      examCode: exams[0]?.code || '',
      ageMin: 0,
      ageMax: 120,
      sex: 'Todos',
      unit: 'mg/dL',
      valMin: 0,
      valMax: 100,
      textReference: '',
      observations: ''
    });
    setShowAddForm(false);
  };

  // Edit Range manual save
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRange) return;

    const updatedList = referenceRanges.map(r => r.id === editingRange.id ? {
      ...editingRange,
      valMin: editingRange.valMin === null || editingRange.valMin === '' || isNaN(Number(editingRange.valMin)) ? null : Number(editingRange.valMin),
      valMax: editingRange.valMax === null || editingRange.valMax === '' || isNaN(Number(editingRange.valMax)) ? null : Number(editingRange.valMax),
    } : r);

    onUpdateRanges(updatedList);
    onAddAuditLog('Valores Referencia - Editar', `Modificó rangos de referencia para examen ${editingRange.examCode} (ID: ${editingRange.id})`);
    setEditingRange(null);
  };

  // Delete Range
  const handleDeleteRange = (id: string) => {
    if (!confirm('¿Está seguro de eliminar este rango de referencia?')) return;
    const target = referenceRanges.find(r => r.id === id);
    const updatedList = referenceRanges.filter(r => r.id !== id);
    onUpdateRanges(updatedList);
    onAddAuditLog('Valores Referencia - Eliminar', `Eliminó el rango de referencia ${id} de la prueba ${target?.examCode}`);
  };

  // Import Ranges via Excel/CSV
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        const rawJson = XLSX.utils.sheet_to_json<any>(worksheet);
        
        if (rawJson.length === 0) {
          alert('El archivo cargado está vacío.');
          return;
        }

        const importedRanges: ReferenceRange[] = rawJson.map((row, idx) => {
          const examCode = (row['Código Examen'] || row['Codigo Examen'] || row['examCode'] || '').toString().toUpperCase().trim();
          const ageMin = parseInt(row['Edad Mínima'] || row['Edad Minima'] || row['ageMin'] || '0');
          const ageMax = parseInt(row['Edad Máxima'] || row['Edad Maxima'] || row['ageMax'] || '120');
          const sex = (row['Sexo'] || row['sex'] || 'Todos').toString().trim() as 'M' | 'F' | 'Todos';
          const unit = (row['Unidad'] || row['unit'] || 'mg/dL').toString().trim();
          
          const rawMin = row['Valor Mínimo'] || row['Valor Minimo'] || row['valMin'];
          const rawMax = row['Valor Máximo'] || row['Valor Maximo'] || row['valMax'];
          const valMin = (rawMin !== undefined && rawMin !== null && rawMin !== '') ? parseFloat(rawMin) : null;
          const valMax = (rawMax !== undefined && rawMax !== null && rawMax !== '') ? parseFloat(rawMax) : null;

          const textReference = (row['Texto Referencia'] || row['textReference'] || '').toString().trim();
          const observations = (row['Observaciones'] || row['observations'] || '').toString().trim();

          return {
            id: `REF-${2000 + idx}`,
            examCode,
            ageMin: isNaN(ageMin) ? 0 : ageMin,
            ageMax: isNaN(ageMax) ? 120 : ageMax,
            sex: (sex === 'M' || sex === 'F') ? sex : 'Todos',
            unit,
            valMin: (valMin !== null && !isNaN(valMin)) ? valMin : null,
            valMax: (valMax !== null && !isNaN(valMax)) ? valMax : null,
            textReference: textReference || undefined,
            observations: observations || undefined
          };
        });

        const validImported = importedRanges.filter(r => r.examCode);

        if (confirm(`Se cargaron ${validImported.length} rangos de referencia. ¿Desea REEMPLAZAR todos los rangos existentes?`)) {
          onUpdateRanges(validImported);
          onAddAuditLog('Valores Referencia - Reemplazo masivo', `Reemplazó el catálogo completo de rangos de referencia con ${validImported.length} registros.`);
        } else {
          const merged = [...referenceRanges, ...validImported];
          onUpdateRanges(merged);
          onAddAuditLog('Valores Referencia - Fusión masiva', `Agregó ${validImported.length} nuevos rangos de referencia.`);
        }

        alert('¡Importación exitosa de valores de referencia!');
        if (fileInputRef.current) fileInputRef.current.value = '';
      } catch (err) {
        console.error(err);
        alert('Error importando el archivo. Asegúrese que tenga las columnas correctas.');
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Export Ranges to Excel
  const handleExportFile = () => {
    const dataToExport = referenceRanges.map(r => {
      const exam = exams.find(e => e.code === r.examCode);
      return {
        'Código Examen': r.examCode,
        'Nombre Examen': exam ? exam.name : 'N/A',
        'Edad Mínima': r.ageMin,
        'Edad Máxima': r.ageMax,
        'Sexo': r.sex,
        'Unidad': r.unit,
        'Valor Mínimo': r.valMin ?? '',
        'Valor Máximo': r.valMax ?? '',
        'Texto Referencia': r.textReference ?? '',
        'Observaciones': r.observations ?? ''
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Valores de Referencia');

    worksheet['!cols'] = Object.keys(dataToExport[0] || {}).map(() => ({ wch: 15 }));

    XLSX.writeFile(workbook, `valores_referencia_lis_${new Date().toISOString().split('T')[0]}.xlsx`);
    onAddAuditLog('Valores Referencia - Exportación', 'Exportó todos los rangos de referencia clínica a un archivo Excel.');
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Valores de Referencia Clínica</h1>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Configure parámetros de normalidad por edad y sexo, prepare descripciones cualitativas, e importe datos masivos por Excel.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept=".xlsx,.xls,.csv"
            onChange={handleImportFile}
          />
          <button
            id="ref_btn_import"
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-md border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> Importar Excel
          </button>
          <button
            id="ref_btn_export"
            onClick={handleExportFile}
            className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-md border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-blue-600" /> Exportar Excel
          </button>
          <button
            id="ref_btn_add"
            onClick={() => setShowAddForm(true)}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Nuevo Rango
          </button>
        </div>
      </div>

      {/* Info Warning */}
      <div className="bg-blue-50/65 border border-blue-200 p-3 rounded-lg text-[11px] text-blue-800 flex gap-2.5 leading-relaxed font-medium">
        <Info className="w-4.5 h-4.5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Regla del Sistema LIS El Salvador:</span> Según requerimientos regulatorios, los resultados se reportarán exactamente junto a estos rangos. El sistema no generará alarmas automáticas arbitrarias para no interferir con la interpretación clínica cualificada.
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
          <input
            id="ref_search_input"
            type="text"
            placeholder="Buscar por código de examen o prueba..."
            className="w-full pl-8 pr-4 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800 placeholder-slate-400"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Sexo:</span>
          <select
            id="ref_sex_filter"
            className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-750 font-bold"
            value={selectedSexFilter}
            onChange={(e) => setSelectedSexFilter(e.target.value as any)}
          >
            <option value="Todos_Filtro">Todos</option>
            <option value="M">Masculino (M)</option>
            <option value="F">Femenino (F)</option>
            <option value="Todos">Unisex (Todos)</option>
          </select>
        </div>
      </div>

      {/* Ranges Table List */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/85 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                <th className="py-2.5 px-3">ID Rango</th>
                <th className="py-2.5 px-3">Prueba Vinculada</th>
                <th className="py-2.5 px-3">Rango Edades</th>
                <th className="py-2.5 px-3 text-center">Sexo</th>
                <th className="py-2.5 px-3 font-mono text-center">Rango Numérico</th>
                <th className="py-2.5 px-3">Patrón Cualitativo</th>
                <th className="py-2.5 px-3">Unidad</th>
                <th className="py-2.5 px-3">Observaciones</th>
                <th className="py-2.5 px-3 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRanges.map((range) => {
                const exam = exams.find(e => e.code === range.examCode);
                return (
                  <tr key={range.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2 px-3 font-mono font-bold text-slate-500">{range.id}</td>
                    <td className="py-2 px-3">
                      <div className="font-bold text-slate-800">{exam ? exam.name : 'N/A'}</div>
                      <div className="text-[10px] text-slate-400 font-mono font-bold">{range.examCode}</div>
                    </td>
                    <td className="py-2 px-3 text-slate-700 font-semibold">{range.ageMin} - {range.ageMax} años</td>
                    <td className="py-2 px-3 text-center">
                      <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
                        range.sex === 'M' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                        range.sex === 'F' ? 'bg-pink-50 text-pink-700 border border-pink-100' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {range.sex}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-mono text-center font-bold text-slate-900">
                      {range.valMin !== null && range.valMax !== null ? (
                        <span>{range.valMin} - {range.valMax}</span>
                      ) : range.valMax !== null ? (
                        <span>&lt; {range.valMax}</span>
                      ) : range.valMin !== null ? (
                        <span>&gt; {range.valMin}</span>
                      ) : (
                        <span className="text-slate-400 italic font-sans font-normal">Cualitativo</span>
                      )}
                    </td>
                    <td className="py-2 px-3 text-slate-650 font-medium truncate max-w-xs" title={range.textReference}>
                      {range.textReference || '-'}
                    </td>
                    <td className="py-2 px-3 font-bold text-slate-600">{range.unit}</td>
                    <td className="py-2 px-3 text-slate-500 max-w-xs truncate" title={range.observations}>
                      {range.observations || '-'}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <div className="flex justify-center items-center gap-1.5">
                        <button
                          id={`ref_edit_btn_` + range.id}
                          onClick={() => setEditingRange(range)}
                          className="p-1 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer border border-transparent hover:border-slate-150"
                          title="Editar rango"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          id={`ref_del_btn_` + range.id}
                          onClick={() => handleDeleteRange(range.id)}
                          className="p-1 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer border border-transparent hover:border-slate-150"
                          title="Eliminar rango"
                        >
                          <Trash className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredRanges.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-slate-400 font-semibold text-xs">
                    No se encontraron parámetros de referencia clínicos configurados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Add Range */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-5 space-y-3.5 border border-slate-250">
            <div className="flex justify-between items-center pb-1.5 border-b border-slate-150">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Crear Rango de Referencia</h3>
              <button 
                id="close_add_range_modal"
                onClick={() => setShowAddForm(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleAddRange} className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Prueba Clínica Vinculada *</label>
                <select
                  id="new_range_exam_code"
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                  value={newRange.examCode}
                  onChange={(e) => setNewRange(prev => ({ ...prev, examCode: e.target.value }))}
                >
                  {exams.map(e => (
                    <option key={e.code} value={e.code}>{e.name} ({e.code})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Edad Mín. *</label>
                  <input
                    id="new_range_age_min"
                    type="number"
                    required
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={newRange.ageMin}
                    onChange={(e) => setNewRange(prev => ({ ...prev, ageMin: parseInt(e.target.value) || 0 }))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Edad Máx. *</label>
                  <input
                    id="new_range_age_max"
                    type="number"
                    required
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={newRange.ageMax}
                    onChange={(e) => setNewRange(prev => ({ ...prev, ageMax: parseInt(e.target.value) || 120 }))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Sexo *</label>
                  <select
                    id="new_range_sex"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                    value={newRange.sex}
                    onChange={(e) => setNewRange(prev => ({ ...prev, sex: e.target.value as any }))}
                  >
                    <option value="Todos">Unisex</option>
                    <option value="M">Masculino (M)</option>
                    <option value="F">Femenino (F)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Val. Mínimo</label>
                  <input
                    id="new_range_val_min"
                    type="number"
                    step="0.01"
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700"
                    value={newRange.valMin ?? ''}
                    onChange={(e) => setNewRange(prev => ({ ...prev, valMin: e.target.value === '' ? null : parseFloat(e.target.value) }))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Val. Máximo</label>
                  <input
                    id="new_range_val_max"
                    type="number"
                    step="0.01"
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700"
                    value={newRange.valMax ?? ''}
                    onChange={(e) => setNewRange(prev => ({ ...prev, valMax: e.target.value === '' ? null : parseFloat(e.target.value) }))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Unidad Medida</label>
                  <input
                    id="new_range_unit"
                    type="text"
                    required
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={newRange.unit}
                    onChange={(e) => setNewRange(prev => ({ ...prev, unit: e.target.value }))}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Referencia Cualitativa (Opcional)</label>
                <textarea
                  id="new_range_text"
                  rows={2}
                  placeholder="e.g. Negativo / Ausencia de bacterias..."
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                  value={newRange.textReference}
                  onChange={(e) => setNewRange(prev => ({ ...prev, textReference: e.target.value }))}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Observaciones</label>
                <input
                  id="new_range_obs"
                  type="text"
                  placeholder="Observaciones de interpretación clínica..."
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                  value={newRange.observations}
                  onChange={(e) => setNewRange(prev => ({ ...prev, observations: e.target.value }))}
                />
              </div>

              <button
                id="btn_submit_add_range"
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors cursor-pointer"
              >
                Vincular Parámetro
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Range */}
      {editingRange && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-5 space-y-3.5 border border-slate-250">
            <div className="flex justify-between items-center pb-1.5 border-b border-slate-150">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Editar Rango Referencia</h3>
              <button 
                id="close_edit_range_modal"
                onClick={() => setEditingRange(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Prueba Clínica</label>
                <input
                  type="text"
                  disabled
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-100 border border-slate-200 rounded-md text-slate-500 font-bold"
                  value={editingRange.examCode}
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Edad Mín. *</label>
                  <input
                    id="edit_range_age_min"
                    type="number"
                    required
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                    value={editingRange.ageMin}
                    onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, ageMin: parseInt(e.target.value) || 0 }) : null)}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Edad Máx. *</label>
                  <input
                    id="edit_range_age_max"
                    type="number"
                    required
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                    value={editingRange.ageMax}
                    onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, ageMax: parseInt(e.target.value) || 120 }) : null)}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Sexo *</label>
                  <select
                    id="edit_range_sex"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                    value={editingRange.sex}
                    onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, sex: e.target.value as any }) : null)}
                  >
                    <option value="Todos">Unisex</option>
                    <option value="M">Masculino (M)</option>
                    <option value="F">Femenino (F)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Val. Mínimo</label>
                  <input
                    id="edit_range_val_min"
                    type="number"
                    step="0.01"
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700"
                    value={editingRange.valMin ?? ''}
                    onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, valMin: e.target.value === '' ? null : parseFloat(e.target.value) }) : null)}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Val. Máximo</label>
                  <input
                    id="edit_range_val_max"
                    type="number"
                    step="0.01"
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700"
                    value={editingRange.valMax ?? ''}
                    onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, valMax: e.target.value === '' ? null : parseFloat(e.target.value) }) : null)}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Unidad Medida</label>
                  <input
                    id="edit_range_unit"
                    type="text"
                    required
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                    value={editingRange.unit}
                    onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, unit: e.target.value }) : null)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Referencia Cualitativa (Opcional)</label>
                <textarea
                  id="edit_range_text"
                  rows={2}
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                  value={editingRange.textReference || ''}
                  onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, textReference: e.target.value }) : null)}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Observaciones</label>
                <input
                  id="edit_range_obs"
                  type="text"
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700"
                  value={editingRange.observations || ''}
                  onChange={(e) => setEditingRange(prev => prev ? ({ ...prev, observations: e.target.value }) : null)}
                />
              </div>

              <button
                id="btn_submit_edit_range"
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors cursor-pointer"
              >
                Guardar Modificaciones
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
