/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Plus, 
  Edit, 
  Search, 
  History, 
  Save, 
  X, 
  AlertCircle 
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Exam } from '../types/lis';

interface CatalogProps {
  exams: Exam[];
  onUpdateExams: (exams: Exam[]) => void;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function Catalog({ 
  exams, 
  onUpdateExams,
  onAddAuditLog
}: CatalogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArea, setSelectedArea] = useState('Todas');
  const [editingExam, setEditingExam] = useState<Exam | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showHistoryExam, setShowHistoryExam] = useState<Exam | null>(null);

  // New Exam Form state
  const [newExam, setNewExam] = useState<Omit<Exam, 'priceHistory'>>({
    code: '',
    name: '',
    area: 'Química Clínica',
    price: 0,
    unit: 'mg/dL',
    method: 'Automatizado',
    deliveryTime: '4 horas'
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Computed areas list for filter
  const areas = ['Todas', ...Array.from(new Set(exams.map(e => e.area)))];

  // Search and filter exams
  const filteredExams = exams.filter(exam => {
    const matchesSearch = exam.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          exam.code.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesArea = selectedArea === 'Todas' || exam.area === selectedArea;
    return matchesSearch && matchesArea;
  });

  // Handle manual addition
  const handleAddExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExam.code || !newExam.name || newExam.price <= 0) {
      alert('Por favor complete los campos obligatorios y asegure un precio positivo.');
      return;
    }

    // Check if code already exists
    if (exams.some(e => e.code.toUpperCase() === newExam.code.toUpperCase())) {
      alert('El código de examen ya existe en el catálogo.');
      return;
    }

    const created: Exam = {
      ...newExam,
      code: newExam.code.toUpperCase(),
      priceHistory: [{ date: new Date().toISOString().split('T')[0], price: newExam.price }]
    };

    const updatedCatalog = [...exams, created];
    onUpdateExams(updatedCatalog);
    onAddAuditLog('Catálogo - Agregar Examen', `Agregó manualmente el examen: ${created.name} (${created.code})`);
    
    // reset
    setNewExam({
      code: '',
      name: '',
      area: 'Química Clínica',
      price: 0,
      unit: 'mg/dL',
      method: 'Automatizado',
      deliveryTime: '4 horas'
    });
    setShowAddForm(false);
  };

  // Handle manual editing
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExam) return;

    const originalExam = exams.find(e => e.code === editingExam.code);
    if (!originalExam) return;

    let updatedHistory = originalExam.priceHistory ? [...originalExam.priceHistory] : [];
    // If price changed, keep history
    if (originalExam.price !== editingExam.price) {
      updatedHistory.push({
        date: new Date().toISOString().split('T')[0],
        price: editingExam.price
      });
      onAddAuditLog(
        'Catálogo - Cambio de Precio', 
        `Actualizó precio de ${editingExam.name} de $${originalExam.price.toFixed(2)} a $${editingExam.price.toFixed(2)}`
      );
    }

    const updated: Exam = {
      ...editingExam,
      priceHistory: updatedHistory
    };

    const updatedCatalog = exams.map(e => e.code === editingExam.code ? updated : e);
    onUpdateExams(updatedCatalog);
    onAddAuditLog('Catálogo - Editar Examen', `Editó los datos del examen: ${editingExam.name} (${editingExam.code})`);
    setEditingExam(null);
  };

  // Excel / CSV File Import Action
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        // Convert to JSON
        const rawJson = XLSX.utils.sheet_to_json<any>(worksheet);
        
        if (rawJson.length === 0) {
          alert('El archivo cargado está vacío.');
          return;
        }

        // Validate structure and map fields
        const importedExams: Exam[] = rawJson.map((row, idx) => {
          // Normalize column headers
          const code = (row['Código'] || row['Codigo'] || row['code'] || row['ID'] || `EX-${100 + idx}`).toString().toUpperCase().trim();
          const name = (row['Nombre'] || row['nombre'] || row['name'] || 'Examen Importado').toString().trim();
          const area = (row['Área'] || row['Area'] || row['area'] || 'General').toString().trim();
          const price = parseFloat(row['Precio'] || row['precio'] || row['price'] || '10.0');
          const unit = (row['Unidad'] || row['unidad'] || row['unit'] || 'mg/dL').toString().trim();
          const method = (row['Método'] || row['Metodo'] || row['method'] || 'Automatizado').toString().trim();
          const deliveryTime = (row['Tiempo de Entrega'] || row['Tiempo'] || row['deliveryTime'] || '12 horas').toString().trim();

          return {
            code,
            name,
            area,
            price: isNaN(price) ? 10.0 : price,
            unit,
            method,
            deliveryTime
          };
        });

        // Merge imported with existing without losing historical prices
        const updatedCatalog = [...exams];
        let addedCount = 0;
        let updatedCount = 0;

        importedExams.forEach(imp => {
          const idx = updatedCatalog.findIndex(ex => ex.code === imp.code);
          if (idx > -1) {
            // Exam already exists - update fields
            const original = updatedCatalog[idx];
            let history = original.priceHistory ? [...original.priceHistory] : [];
            if (original.price !== imp.price) {
              history.push({
                date: new Date().toISOString().split('T')[0],
                price: imp.price
              });
            }
            updatedCatalog[idx] = {
              ...imp,
              priceHistory: history
            };
            updatedCount++;
          } else {
            // New exam
            updatedCatalog.push({
              ...imp,
              priceHistory: [{ date: new Date().toISOString().split('T')[0], price: imp.price }]
            });
            addedCount++;
          }
        });

        onUpdateExams(updatedCatalog);
        onAddAuditLog(
          'Catálogo - Importación', 
          `Importó catálogo por archivo. Registros agregados: ${addedCount}, actualizados: ${updatedCount}.`
        );
        alert(`¡Importación exitosa! ${addedCount} exámenes agregados, ${updatedCount} actualizados.`);
        
        if (fileInputRef.current) fileInputRef.current.value = ''; // clear input
      } catch (err) {
        console.error(err);
        alert('Error leyendo el archivo Excel/CSV. Verifique el formato.');
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Export Catalog back to Excel
  const handleExportFile = () => {
    const dataToExport = exams.map(e => ({
      'Código': e.code,
      'Nombre': e.name,
      'Área': e.area,
      'Precio ($)': e.price,
      'Unidad': e.unit,
      'Método': e.method,
      'Tiempo de Entrega': e.deliveryTime
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Catálogo Exámenes');

    // Auto fit column widths
    const maxLens = Object.keys(dataToExport[0] || {}).map(() => 15);
    worksheet['!cols'] = maxLens.map(l => ({ wch: l }));

    XLSX.writeFile(workbook, `catalogo_examenes_lis_${new Date().toISOString().split('T')[0]}.xlsx`);
    onAddAuditLog('Catálogo - Exportación', 'Exportó el catálogo completo de exámenes a un archivo Excel.');
  };

  return (
    <div className="space-y-4">
      {/* Header controls */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Catálogo de Exámenes Clínicos</h1>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Administre el portafolio de pruebas, actualice listas de precios con trazabilidad histórica e importe/exporte hojas Excel de forma directa.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept=".xlsx,.xls,.csv"
            onChange={handleImportFile}
          />
          <button
            id="cat_btn_import"
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-md border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> Importar Excel
          </button>
          <button
            id="cat_btn_export"
            onClick={handleExportFile}
            className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-md border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-blue-600" /> Exportar Excel
          </button>
          <button
            id="cat_btn_add"
            onClick={() => setShowAddForm(true)}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Nuevo Examen
          </button>
        </div>
      </div>

      {/* Search and Area Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3 bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
          <input
            id="cat_search_input"
            type="text"
            placeholder="Buscar por nombre o código de prueba..."
            className="w-full pl-8 pr-4 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800 placeholder-slate-400"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Área:</span>
          <select
            id="cat_area_filter"
            className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-semibold"
            value={selectedArea}
            onChange={(e) => setSelectedArea(e.target.value)}
          >
            {areas.map(a => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Catalog List & Edit Form Drawer */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/85 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                <th className="py-2.5 px-3">Código</th>
                <th className="py-2.5 px-3">Examen</th>
                <th className="py-2.5 px-3">Área Clínica</th>
                <th className="py-2.5 px-3 font-mono text-right">Precio ($)</th>
                <th className="py-2.5 px-3">Unidad</th>
                <th className="py-2.5 px-3">Método Analítico</th>
                <th className="py-2.5 px-3">Tiempo Entrega</th>
                <th className="py-2.5 px-3 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredExams.map((exam) => (
                <tr key={exam.code} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2 px-3 font-mono font-bold text-blue-600">{exam.code}</td>
                  <td className="py-2 px-3">
                    <div className="font-bold text-slate-900">{exam.name}</div>
                  </td>
                  <td className="py-2 px-3">
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-100 text-slate-700">
                      {exam.area}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-mono text-right font-bold text-slate-950">${exam.price.toFixed(2)}</td>
                  <td className="py-2 px-3 text-slate-600">{exam.unit}</td>
                  <td className="py-2 px-3 text-slate-500 italic">{exam.method}</td>
                  <td className="py-2 px-3 text-slate-600">{exam.deliveryTime}</td>
                  <td className="py-2 px-3 text-center">
                    <div className="flex justify-center items-center gap-1.5">
                      <button
                        id={`cat_edit_btn_` + exam.code}
                        onClick={() => setEditingExam(exam)}
                        className="p-1 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer border border-transparent hover:border-slate-150"
                        title="Editar examen"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        id={`cat_hist_btn_` + exam.code}
                        onClick={() => setShowHistoryExam(exam)}
                        className="p-1 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors cursor-pointer border border-transparent hover:border-slate-150"
                        title="Historial de precios"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredExams.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-400 font-medium text-xs">
                    No se encontraron exámenes con los filtros aplicados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drawer: Add Exam */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-5 space-y-3.5 border border-slate-250">
            <div className="flex justify-between items-center pb-1.5 border-b border-slate-150">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Crear Prueba Clínica</h3>
              <button 
                id="close_add_exam_modal"
                onClick={() => setShowAddForm(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleAddExam} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Código de Prueba *</label>
                  <input
                    id="new_exam_code"
                    type="text"
                    required
                    placeholder="e.g. GLU01"
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 uppercase text-slate-800"
                    value={newExam.code}
                    onChange={(e) => setNewExam(prev => ({ ...prev, code: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Área Clínica *</label>
                  <select
                    id="new_exam_area"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-semibold"
                    value={newExam.area}
                    onChange={(e) => setNewExam(prev => ({ ...prev, area: e.target.value }))}
                  >
                    <option value="Química Clínica">Química Clínica</option>
                    <option value="Hematología">Hematología</option>
                    <option value="Uroanálisis">Uroanálisis</option>
                    <option value="Coprología">Coprología</option>
                    <option value="Inmunología">Inmunología</option>
                    <option value="Microbiología">Microbiología</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Nombre de la Prueba *</label>
                <input
                  id="new_exam_name"
                  type="text"
                  required
                  placeholder="e.g. Glucosa Posprandial"
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                  value={newExam.name}
                  onChange={(e) => setNewExam(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Precio ($) *</label>
                  <input
                    id="new_exam_price"
                    type="number"
                    step="0.01"
                    required
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700"
                    value={newExam.price || ''}
                    onChange={(e) => setNewExam(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Unidad de Medida</label>
                  <input
                    id="new_exam_unit"
                    type="text"
                    placeholder="e.g. mg/dL, %"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-850"
                    value={newExam.unit}
                    onChange={(e) => setNewExam(prev => ({ ...prev, unit: e.target.value }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Método Analítico</label>
                  <input
                    id="new_exam_method"
                    type="text"
                    placeholder="e.g. Enzimático"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-850"
                    value={newExam.method}
                    onChange={(e) => setNewExam(prev => ({ ...prev, method: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Entrega Promedio</label>
                  <input
                    id="new_exam_delivery"
                    type="text"
                    placeholder="e.g. 4 horas, 24 horas"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-850"
                    value={newExam.deliveryTime}
                    onChange={(e) => setNewExam(prev => ({ ...prev, deliveryTime: e.target.value }))}
                  />
                </div>
              </div>

              <button
                id="btn_submit_add_exam"
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors cursor-pointer"
              >
                Agregar al Catálogo
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Drawer: Edit Exam */}
      {editingExam && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-5 space-y-3.5 border border-slate-250">
            <div className="flex justify-between items-center pb-1.5 border-b border-slate-150">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Editar Examen Clínico</h3>
              <button 
                id="close_edit_exam_modal"
                onClick={() => setEditingExam(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Código (No Editable)</label>
                <input
                  type="text"
                  disabled
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-100 border border-slate-200 rounded-md text-slate-500"
                  value={editingExam.code}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Nombre Completo *</label>
                <input
                  id="edit_exam_name"
                  type="text"
                  required
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                  value={editingExam.name}
                  onChange={(e) => setEditingExam(prev => prev ? ({ ...prev, name: e.target.value }) : null)}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Área Clínica</label>
                  <select
                    id="edit_exam_area"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700 font-semibold"
                    value={editingExam.area}
                    onChange={(e) => setEditingExam(prev => prev ? ({ ...prev, area: e.target.value }) : null)}
                  >
                    <option value="Química Clínica">Química Clínica</option>
                    <option value="Hematología">Hematología</option>
                    <option value="Uroanálisis">Uroanálisis</option>
                    <option value="Coprología">Coprología</option>
                    <option value="Inmunología">Inmunología</option>
                    <option value="Microbiología">Microbiología</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Precio ($) *</label>
                  <input
                    id="edit_exam_price"
                    type="number"
                    step="0.01"
                    required
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-700"
                    value={editingExam.price}
                    onChange={(e) => setEditingExam(prev => prev ? ({ ...prev, price: parseFloat(e.target.value) || 0 }) : null)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Unidad</label>
                  <input
                    id="edit_exam_unit"
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={editingExam.unit}
                    onChange={(e) => setEditingExam(prev => prev ? ({ ...prev, unit: e.target.value }) : null)}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Método Analítico</label>
                  <input
                    id="edit_exam_method"
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={editingExam.method}
                    onChange={(e) => setEditingExam(prev => prev ? ({ ...prev, method: e.target.value }) : null)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Tiempo de Entrega</label>
                <input
                  id="edit_exam_delivery"
                  type="text"
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-850"
                  value={editingExam.deliveryTime}
                  onChange={(e) => setEditingExam(prev => prev ? ({ ...prev, deliveryTime: e.target.value }) : null)}
                />
              </div>

              <button
                id="btn_submit_edit_exam"
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors cursor-pointer"
              >
                Guardar Modificaciones
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Price history logs */}
      {showHistoryExam && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-xs w-full p-5 space-y-3.5 border border-slate-250">
            <div className="flex justify-between items-center pb-1.5 border-b border-slate-150">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                <History className="w-4 h-4 text-emerald-600" />
                Historial de Tarifas
              </h3>
              <button 
                id="close_history_modal"
                onClick={() => setShowHistoryExam(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              <div>
                <h4 className="text-xs font-bold text-slate-900">{showHistoryExam.name}</h4>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Código LIS: {showHistoryExam.code}</p>
              </div>

              <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1">
                {showHistoryExam.priceHistory && showHistoryExam.priceHistory.length > 0 ? (
                  showHistoryExam.priceHistory.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-xs py-1 border-b border-dashed border-slate-100">
                      <span className="text-slate-500">{item.date}</span>
                      <span className="font-mono font-bold text-slate-850">${item.price.toFixed(2)}</span>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-xs text-slate-400 flex flex-col items-center gap-1">
                    <AlertCircle className="w-4.5 h-4.5 text-slate-300" />
                    <span>No hay registros históricos de precios.</span>
                  </div>
                )}
              </div>
            </div>

            <button
              id="btn_close_history"
              onClick={() => setShowHistoryExam(null)}
              className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-md cursor-pointer border border-slate-200"
            >
              Cerrar Historial
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
