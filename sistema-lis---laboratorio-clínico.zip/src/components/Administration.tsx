/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Users, 
  ShieldAlert, 
  Database, 
  Settings, 
  TrendingUp, 
  Lock, 
  UserPlus, 
  Upload, 
  Download, 
  CheckCircle, 
  XCircle, 
  FileText 
} from 'lucide-react';
import { User as LisUser, AuditLog, Order, Patient, Exam, LetterheadConfig } from '../types/lis';

interface AdministrationProps {
  users: LisUser[];
  auditLogs: AuditLog[];
  orders: Order[];
  patients: Patient[];
  exams: Exam[];
  currentUser: LisUser;
  onUpdateCurrentUser: (user: LisUser) => void;
  onUpdateUsers: (users: LisUser[]) => void;
  onRestoreDatabase: (dbState: {
    patients: Patient[];
    orders: Order[];
    exams: Exam[];
    auditLogs: AuditLog[];
  }) => void;
  onAddAuditLog: (action: string, details: string) => void;
  letterhead: LetterheadConfig;
  onUpdateLetterhead: (config: LetterheadConfig) => void;
}

export default function Administration({ 
  users, 
  auditLogs, 
  orders, 
  patients, 
  exams, 
  currentUser,
  onUpdateCurrentUser,
  onUpdateUsers,
  onRestoreDatabase,
  onAddAuditLog,
  letterhead,
  onUpdateLetterhead
}: AdministrationProps) {
  const [activeTab, setActiveTab] = useState<'usuarios' | 'membrete' | 'auditoria' | 'respaldos' | 'estadisticas'>('usuarios');
  
  // Create User form state
  const [showAddUserForm, setShowAddUserForm] = useState(false);
  const [newUser, setNewUser] = useState<Omit<LisUser, 'id'>>({
    username: '',
    name: '',
    role: 'Recepcionista',
    signature: '',
    active: true
  });

  // Handle Switch active user role simulator
  const handleSwitchUserSim = (username: string) => {
    const target = users.find(u => u.username === username);
    if (target) {
      onUpdateCurrentUser(target);
      onAddAuditLog('Cambio de Sesión', `Simuló inicio de sesión como: ${target.name} con el rol de ${target.role}`);
    }
  };

  // Create User
  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.username || !newUser.name) {
      alert('Por favor complete los campos obligatorios.');
      return;
    }

    if (users.some(u => u.username.toLowerCase() === newUser.username.toLowerCase())) {
      alert('El nombre de usuario ya existe.');
      return;
    }

    const created: LisUser = {
      id: `USR-${100 + users.length + 1}`,
      ...newUser,
      signature: newUser.role !== 'Recepcionista' ? `${newUser.name} - Reg. JVPM ${Math.floor(1000 + Math.random() * 9000)}` : undefined
    };

    onUpdateUsers([...users, created]);
    onAddAuditLog('Administración - Crear Usuario', `Registró al usuario de sistema: ${created.name} con el rol de ${created.role}`);
    
    // Reset
    setNewUser({
      username: '',
      name: '',
      role: 'Recepcionista',
      signature: '',
      active: true
    });
    setShowAddUserForm(false);
  };

  // Toggle user state
  const toggleUserActive = (id: string) => {
    const updated = users.map(u => {
      if (u.id === id) {
        const nextState = !u.active;
        onAddAuditLog('Administración - Estado Usuario', `Cambió estado del usuario ${u.username} a ${nextState ? 'Activo' : 'Inactivo'}`);
        return { ...u, active: nextState };
      }
      return u;
    });
    onUpdateUsers(updated);
  };

  // Database Backup download
  const handleDownloadBackup = () => {
    const backupData = {
      timestamp: new Date().toISOString(),
      source: "LIS El Salvador",
      patients,
      orders,
      exams,
      auditLogs
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `respaldo_base_datos_lis_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    onAddAuditLog('Copia de Seguridad - Exportación', 'Exportó una copia de seguridad JSON completa de la base de datos clínica.');
  };

  // Restore database from Backup file upload
  const handleRestoreBackupUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.patients && parsed.orders && parsed.exams && parsed.auditLogs) {
          if (confirm('¿Está seguro de RESTAURAR esta base de datos? Esto reemplazará todos los pacientes, órdenes y catálogos actuales.')) {
            onRestoreDatabase({
              patients: parsed.patients,
              orders: parsed.orders,
              exams: parsed.exams,
              auditLogs: [
                {
                  id: `LOG-${Date.now()}`,
                  timestamp: new Date().toISOString(),
                  userId: currentUser.id,
                  username: currentUser.username,
                  role: currentUser.role,
                  action: "Copia de Seguridad - Restauración",
                  details: `Restauró exitosamente base de datos desde respaldo oficial fechado el ${parsed.timestamp}.`
                },
                ...parsed.auditLogs
              ]
            });
            alert('¡Base de datos restaurada correctamente!');
          }
        } else {
          alert('El archivo no tiene el formato de copia de seguridad LIS correcto.');
        }
      } catch (err) {
        console.error(err);
        alert('Error interpretando el archivo de respaldo.');
      }
    };
    reader.readAsText(file);
  };

  // Calculations for Statistics Tab
  const statsSummary = useMemo(() => {
    const totalOrders = orders.length;
    const validatedOrders = orders.filter(o => o.status === 'Validado').length;
    const pendingOrders = orders.filter(o => o.status === 'Pendiente').length;
    
    // Total income from paid bills
    const income = orders
      .filter(o => o.paymentStatus === 'Pagado')
      .reduce((sum, o) => sum + o.totalAmount, 0);

    const paidCount = orders.filter(o => o.paymentStatus === 'Pagado').length;
    const pendingPayCount = orders.filter(o => o.paymentStatus === 'Pendiente').length;
    const exemptCount = orders.filter(o => o.paymentStatus === 'Exento').length;

    const avgOrderVal = totalOrders > 0 ? (income / paidCount || 0) : 0;

    return {
      totalOrders,
      validatedOrders,
      pendingOrders,
      income,
      paidCount,
      pendingPayCount,
      exemptCount,
      avgOrderVal
    };
  }, [orders]);

  return (
    <div className="space-y-4">
      {/* Simulation / Role swap Top banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3 shadow-3xs">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-amber-100 rounded text-amber-800">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-amber-950 uppercase tracking-wide">Simulador de Credenciales / Seguridad</h4>
            <p className="text-[10px] text-amber-850 mt-0.5 font-medium">
              Operando como <strong className="font-extrabold">{currentUser.name}</strong> ({currentUser.role}). Cambie de rol para probar las restricciones LIS.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider">Usuario Activo:</span>
          <select
            id="admin_switch_role_sim"
            className="px-2.5 py-1.5 text-xs bg-white border border-amber-300 rounded-md focus:outline-hidden text-slate-800 font-bold"
            value={currentUser.username}
            onChange={(e) => handleSwitchUserSim(e.target.value)}
          >
            {users.map(u => (
              <option key={u.username} value={u.username}>{u.name} ({u.role})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex border-b border-slate-200 bg-white p-0.5 rounded-lg border border-slate-200">
        {(['usuarios', 'membrete', 'auditoria', 'respaldos', 'estadisticas'] as const).map(tab => (
          <button
            id={`admin_tab_` + tab}
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer rounded-md ${
              activeTab === tab 
                ? 'bg-blue-600 text-white shadow-3xs font-black' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            {tab === 'usuarios' && 'Usuarios & Firma'}
            {tab === 'membrete' && 'Membrete Oficial'}
            {tab === 'auditoria' && 'Auditoría LIS'}
            {tab === 'respaldos' && 'Copias Seguridad'}
            {tab === 'estadisticas' && 'Métricas LIS'}
          </button>
        ))}
      </div>

      {/* TAB: USERS */}
      {activeTab === 'usuarios' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-white p-3 rounded-lg border border-slate-200 shadow-3xs">
            <div>
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Personal LIS y Firma Autorizada</h2>
              <p className="text-[10px] text-slate-500 mt-0.5">Control de cuentas de acceso, roles analíticos y certificados JVPM de firmas estampadas.</p>
            </div>
            {currentUser.role === 'Administrador' && (
              <button
                id="admin_btn_add_user"
                onClick={() => setShowAddUserForm(true)}
                className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md flex items-center gap-1.5 cursor-pointer shadow-3xs"
              >
                <UserPlus className="w-3.5 h-3.5" /> Nuevo Personal
              </button>
            )}
          </div>

          <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/85 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-2.5 px-3">Código USR</th>
                  <th className="py-2.5 px-3">Nombre Oficial</th>
                  <th className="py-2.5 px-3">Usuario</th>
                  <th className="py-2.5 px-3">Rol del Sistema</th>
                  <th className="py-2.5 px-3">Firma Digital Estampada</th>
                  <th className="py-2.5 px-3 text-center">Estado Cuenta</th>
                  <th className="py-2.5 px-3 text-center">Simulador</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2 px-3 font-mono text-slate-500 font-bold">{user.id}</td>
                    <td className="py-2 px-3 font-bold text-slate-850">{user.name}</td>
                    <td className="py-2 px-3 font-mono text-slate-600">{user.username}</td>
                    <td className="py-2 px-3">
                      <span className={`inline-flex px-1.5 py-0.2 text-[9px] font-black rounded ${
                        user.role === 'Administrador' ? 'bg-red-50 text-red-800 border border-red-200' :
                        user.role === 'Tecnólogo' ? 'bg-blue-50 text-blue-800 border border-blue-200' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-slate-500 font-semibold italic">
                      {user.signature || 'No requiere firma'}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <button
                        id={`user_toggle_` + user.id}
                        disabled={currentUser.role !== 'Administrador' || user.id === currentUser.id}
                        onClick={() => toggleUserActive(user.id)}
                        className="inline-flex items-center gap-1 cursor-pointer disabled:opacity-50 text-[10px] font-bold"
                      >
                        {user.active ? (
                          <span className="text-emerald-600 flex items-center gap-1 font-black"><CheckCircle className="w-3.5 h-3.5" /> ACTIVO</span>
                        ) : (
                          <span className="text-red-650 flex items-center gap-1 font-black"><XCircle className="w-3.5 h-3.5" /> INACTIVO</span>
                        )}
                      </button>
                    </td>
                    <td className="py-2 px-3 text-center">
                      <button
                        id={`sim_login_` + user.username}
                        onClick={() => handleSwitchUserSim(user.username)}
                        className="px-2 py-0.5 text-[9px] font-black bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors cursor-pointer border border-slate-200"
                      >
                        SIMULAR ACCESO
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* New User Form Drawer Modal */}
          {showAddUserForm && (
            <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5 space-y-3.5 border border-slate-250">
                <div className="flex justify-between items-center pb-1.5 border-b border-slate-150">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Registrar Personal de Laboratorio</h3>
                  <button 
                    id="close_user_modal"
                    onClick={() => setShowAddUserForm(false)}
                    className="text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <XCircle className="w-4.5 h-4.5" />
                  </button>
                </div>

                <form onSubmit={handleCreateUser} className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Nombre Completo *</label>
                    <input
                      id="new_user_name"
                      type="text"
                      required
                      placeholder="e.g. Dr. Alejandro Méndez"
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800"
                      value={newUser.name}
                      onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Usuario *</label>
                      <input
                        id="new_user_username"
                        type="text"
                        required
                        placeholder="e.g. amendez"
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-850 font-mono"
                        value={newUser.username}
                        onChange={(e) => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase tracking-wide">Rol *</label>
                      <select
                        id="new_user_role"
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-700 font-bold"
                        value={newUser.role}
                        onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value as any }))}
                      >
                        <option value="Administrador">Administrador</option>
                        <option value="Tecnólogo">Tecnólogo</option>
                        <option value="Recepcionista">Recepcionista</option>
                      </select>
                    </div>
                  </div>

                  <button
                    id="btn_submit_add_user"
                    type="submit"
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors cursor-pointer"
                  >
                    Guardar Cuenta LIS
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: MEMBRETE */}
      {activeTab === 'membrete' && (
        <div className="space-y-4">
          <div className="bg-white p-3.5 rounded-lg border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Configuración del Membrete LIS</h2>
            <p className="text-[10px] text-slate-500 mt-0.5">Defina la identidad del laboratorio clínico para los encabezados y sellos oficiales de los reportes en PDF.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Form */}
            <div className="lg:col-span-7 bg-white p-4 rounded-lg border border-slate-200 space-y-4">
              <h3 className="text-[11px] font-extrabold uppercase text-slate-400 tracking-wider pb-1 border-b border-slate-100">Datos Generales</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">Nombre del Laboratorio</label>
                  <input
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 font-bold"
                    value={letterhead.labName}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, labName: e.target.value })}
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">Eslogan Comercial</label>
                  <input
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800"
                    value={letterhead.slogan}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, slogan: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">CSSP Licencia</label>
                  <input
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 font-mono"
                    value={letterhead.cssp}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, cssp: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">Directora / Propietaria</label>
                  <input
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 font-bold"
                    value={letterhead.ownerName}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, ownerName: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">Inscripción J.V.P.L.C</label>
                  <input
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 font-mono"
                    value={letterhead.jvplc}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, jvplc: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">Teléfono Fijo</label>
                  <input
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 font-mono"
                    value={letterhead.phoneLandline}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, phoneLandline: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">Teléfono Celular</label>
                  <input
                    type="text"
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 font-mono"
                    value={letterhead.phoneCell}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, phoneCell: e.target.value })}
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5 uppercase">Dirección Física Completa</label>
                  <textarea
                    rows={2}
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800"
                    value={letterhead.address}
                    onChange={(e) => onUpdateLetterhead({ ...letterhead, address: e.target.value })}
                  />
                </div>
              </div>

              <div className="pt-2">
                <h3 className="text-[11px] font-extrabold uppercase text-slate-400 tracking-wider pb-1 border-b border-slate-100 mb-2.5">Sello de Hule (Firma y Validación)</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {Array.from({ length: 4 }).map((_, li) => (
                    <div key={li}>
                      <label className="block text-[9px] font-bold text-slate-500 mb-0.5 uppercase">Línea del Sello {li + 1}</label>
                      <input
                        type="text"
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 font-mono"
                        value={letterhead.stampLines[li] || ''}
                        onChange={(e) => {
                          const updatedLines = [...letterhead.stampLines];
                          updatedLines[li] = e.target.value;
                          onUpdateLetterhead({ ...letterhead, stampLines: updatedLines });
                        }}
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    onAddAuditLog('Modificar Membrete', `Actualizó el membrete y logotipo comercial del LIS para ${letterhead.labName}`);
                    alert('Membrete oficial del LIS guardado y sincronizado exitosamente.');
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md shadow-3xs cursor-pointer uppercase tracking-wider"
                >
                  Guardar y Sincronizar Membrete
                </button>
              </div>
            </div>

            {/* Preview Card */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-3 shadow-3xs">
                <h3 className="text-[11px] font-extrabold uppercase text-slate-400 tracking-wider pb-1 border-b border-slate-100">Vista Previa Encabezado</h3>
                <div className="p-3 border border-slate-200 bg-slate-50 rounded-lg text-center md:text-left space-y-1">
                  <h1 className="text-xs font-black text-slate-900 uppercase tracking-tight">{letterhead.labName}</h1>
                  <p className="text-[9px] text-slate-500 font-bold">{letterhead.slogan} • {letterhead.cssp}</p>
                  <p className="text-[8px] text-slate-400 font-medium leading-relaxed">{letterhead.address}</p>
                  <p className="text-[8px] text-slate-500 font-mono font-bold">Tel: {letterhead.phoneLandline} / {letterhead.phoneCell}</p>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-3 shadow-3xs">
                <h3 className="text-[11px] font-extrabold uppercase text-slate-400 tracking-wider pb-1 border-b border-slate-100">Vista Previa Sello Oficial</h3>
                <div className="flex justify-center py-4">
                  <div className="border-4 border-indigo-600/50 p-2.5 rounded-full w-36 h-36 flex flex-col justify-center items-center text-[9px] text-indigo-700/90 font-black tracking-tighter uppercase select-none rotate-[-4deg] bg-indigo-50/10 border-dashed border-spacing-1">
                    <span className="text-[7px] text-indigo-600/60 border-b border-indigo-400/20 pb-0.5 mb-1.5 font-bold">SELLO OFICIAL</span>
                    {letterhead.stampLines.slice(0, 4).map((line, li) => (
                      <span key={li} className="truncate max-w-[120px] text-center font-bold text-[8px] tracking-tight">{line}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: AUDIT LOGS */}
      {activeTab === 'auditoria' && (
        <div className="space-y-3">
          <div className="bg-white p-3 rounded-lg border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Bitácora de Auditoría LIS</h2>
            <p className="text-[10px] text-slate-500 mt-0.5">Listado histórico irreversible para cumplimiento de leyes de salud de El Salvador.</p>
          </div>

          <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-2.5 px-3">Log ID</th>
                  <th className="py-2.5 px-3">Fecha / Hora</th>
                  <th className="py-2.5 px-3">Operador</th>
                  <th className="py-2.5 px-3">Rol</th>
                  <th className="py-2.5 px-3">Acción Ejecutada</th>
                  <th className="py-2.5 px-3">Detalles Técnicos</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-1.5 px-3 font-mono text-slate-400 font-bold">{log.id}</td>
                    <td className="py-1.5 px-3 text-slate-500">
                      {new Date(log.timestamp).toLocaleString('es-SV')}
                    </td>
                    <td className="py-1.5 px-3 font-bold text-slate-800">{log.username}</td>
                    <td className="py-1.5 px-3">
                      <span className="bg-slate-100 px-1.5 py-0.2 rounded text-[9px] font-bold text-slate-600">
                        {log.role}
                      </span>
                    </td>
                    <td className="py-1.5 px-3 text-slate-900 font-bold">{log.action}</td>
                    <td className="py-1.5 px-3 text-slate-500 font-normal leading-normal">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: BACKUPS */}
      {activeTab === 'respaldos' && (
        <div className="space-y-4">
          <div className="bg-white p-3 rounded-lg border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Centro de Respaldo y Recuperación (LIS-DB)</h2>
            <p className="text-[10px] text-slate-500 mt-0.5">Gestione archivos JSON portables para resguardar la base de datos clínica.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Download Backup card */}
            <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-3 flex flex-col justify-between shadow-3xs">
              <div className="space-y-1.5">
                <div className="p-2 bg-blue-50 text-blue-600 rounded w-fit">
                  <Database className="w-5 h-5" />
                </div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">1. Descargar Respaldo Activo</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
                  Genera un archivo JSON consolidando catálogos de exámenes, pacientes registrados, histórico de órdenes clínicas, firmas y log irreversible de auditoría.
                </p>
              </div>

              <button
                id="admin_btn_backup_dl"
                onClick={handleDownloadBackup}
                className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-white font-bold text-xs rounded-md flex items-center justify-center gap-1.5 cursor-pointer transition-all mt-2"
              >
                <Download className="w-3.5 h-3.5" /> Descargar .JSON
              </button>
            </div>

            {/* Restore backup card */}
            <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-3 flex flex-col justify-between shadow-3xs">
              <div className="space-y-1.5">
                <div className="p-2 bg-amber-50 text-amber-600 rounded w-fit">
                  <Upload className="w-5 h-5" />
                </div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">2. Restaurar Copia Seguridad</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
                  Cargue un archivo .json de respaldo válido de este sistema LIS. Esto reescribirá la memoria activa de la base de datos de manera inmediata.
                </p>
              </div>

              <div className="mt-2">
                <input
                  type="file"
                  id="restore_db_file_input"
                  accept=".json"
                  className="hidden"
                  onChange={handleRestoreBackupUpload}
                />
                <button
                  id="admin_btn_backup_ul"
                  onClick={() => document.getElementById('restore_db_file_input')?.click()}
                  className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-md flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <Upload className="w-3.5 h-3.5" /> Restaurar JSON
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: STATISTICS / ANALYTICS */}
      {activeTab === 'estadisticas' && (
        <div className="space-y-4">
          <div className="bg-white p-3 rounded-lg border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Indicadores de Control Operativo y Financiero</h2>
            <p className="text-[10px] text-slate-500 mt-0.5">Estadísticas consolidadas del flujo de órdenes clínicas y recaudación.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-3xs">
              <h3 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2">Resolución de Ensayos LIS</h3>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-slate-950">
                  {statsSummary.totalOrders > 0 
                    ? Math.round((statsSummary.validatedOrders / statsSummary.totalOrders) * 100) 
                    : 0}%
                </span>
                <span className="text-[10px] text-emerald-600 font-bold uppercase">de efectividad</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 font-semibold">
                {statsSummary.validatedOrders} de {statsSummary.totalOrders} órdenes validadas y certificadas con firma médica.
              </p>
            </div>

            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-3xs">
              <h3 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2">Ticket Promedio</h3>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-slate-950">${statsSummary.avgOrderVal.toFixed(2)}</span>
                <span className="text-[10px] text-blue-600 font-bold uppercase">USD promedio</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 font-semibold">
                Monto medio recaudado por transacción de facturación directa en ventanilla de recepción.
              </p>
            </div>

            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-3xs">
              <h3 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2 font-mono">Caja Registrada</h3>
              <div className="space-y-1.5 mt-1.5 font-semibold">
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-500 font-bold">PAGADO</span>
                  <span className="font-bold text-emerald-600">{statsSummary.paidCount} órdenes</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-500 font-bold">PENDIENTE</span>
                  <span className="font-bold text-amber-600">{statsSummary.pendingPayCount} órdenes</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-500 font-bold">CONVENIO / EXENTO</span>
                  <span className="font-bold text-slate-600">{statsSummary.exemptCount} órdenes</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
