/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Search, 
  UserPlus, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Check, 
  Printer, 
  X, 
  Calendar, 
  User, 
  CreditCard,
  Sparkles,
  Flame,
  AlertCircle
} from 'lucide-react';
import { Patient, Exam, Order, AuditLog } from '../types/lis';

interface ReceptionProps {
  patients: Patient[];
  exams: Exam[];
  onAddPatient: (patient: Patient) => void;
  onCreateOrder: (order: Order) => void;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function Reception({ 
  patients, 
  exams, 
  onAddPatient, 
  onCreateOrder,
  onAddAuditLog
}: ReceptionProps) {
  // Quick lookup for existing patients
  const [patientSearch, setPatientSearch] = useState('');
  
  // Patient details (Direct entry & editing)
  const [patientName, setPatientName] = useState('');
  const [patientDui, setPatientDui] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [patientBirthDate, setPatientBirthDate] = useState('1990-01-01');
  const [patientGender, setPatientGender] = useState<'M' | 'F' | 'Otro'>('M');
  const [patientEmail, setPatientEmail] = useState('');

  // Selected existing patient reference (if any)
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);

  // Order Settings
  const [doctorName, setDoctorName] = useState('SOLICITANTE PARTICULAR');
  const [examSearchQuery, setExamSearchQuery] = useState('');
  const [selectedExamCodes, setSelectedExamCodes] = useState<string[]>([]);
  const [isConvenioDoctorSV, setIsConvenioDoctorSV] = useState(false);
  const [isUrgente, setIsUrgente] = useState(false);
  const [examDate, setExamDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Tag Printing Modal
  const [createdOrderForTags, setCreatedOrderForTags] = useState<Order | null>(null);

  // Filter patients based on quick lookup
  const matchedPatients = useMemo(() => {
    if (!patientSearch.trim()) return [];
    const query = patientSearch.toLowerCase();
    return patients.filter(p => 
      p.name.toLowerCase().includes(query) ||
      (p.dui && p.dui.toLowerCase().includes(query)) ||
      (p.phone && p.phone.includes(query)) ||
      p.id.toLowerCase().includes(query)
    );
  }, [patientSearch, patients]);

  // Auto-fill form when existing patient is selected
  const handleSelectExistingPatient = (p: Patient) => {
    setSelectedPatientId(p.id);
    setPatientName(p.name);
    setPatientDui(p.dui || '');
    setPatientPhone(p.phone || '');
    setPatientBirthDate(p.birthDate);
    setPatientGender(p.gender);
    setPatientEmail(p.email || '');
    setPatientSearch(''); // close dropdown
    onAddAuditLog('Admisión - Cargar Paciente', `Seleccionó al paciente existente: ${p.name} (ID: ${p.id})`);
  };

  // Clear patient details form to enter a new one
  const handleClearPatientForm = () => {
    setSelectedPatientId(null);
    setPatientName('');
    setPatientDui('');
    setPatientPhone('');
    setPatientBirthDate('1990-01-01');
    setPatientGender('M');
    setPatientEmail('');
  };

  // Formatting helper for DUI (00000000-0)
  const formatDui = (value: string) => {
    let val = value.replace(/\D/g, ''); // numbers only
    if (val.length > 9) val = val.substring(0, 9);
    if (val.length > 8) {
      val = val.substring(0, 8) + '-' + val.substring(8);
    }
    return val;
  };

  // Formatting helper for Phone (0000-0000)
  const formatPhone = (value: string) => {
    let val = value.replace(/\D/g, '');
    if (val.length > 8) val = val.substring(0, 8);
    if (val.length > 4) {
      val = val.substring(0, 4) + '-' + val.substring(4);
    }
    return val;
  };

  // Group exams by clinical Area
  const groupedExams = useMemo(() => {
    const groups: { [key: string]: Exam[] } = {};
    
    // Sort or filter exams
    const query = examSearchQuery.toLowerCase();
    const filtered = exams.filter(e => 
      e.name.toLowerCase().includes(query) || 
      e.code.toLowerCase().includes(query) ||
      e.area.toLowerCase().includes(query)
    );

    filtered.forEach(exam => {
      const areaUpper = exam.area.toUpperCase();
      if (!groups[areaUpper]) {
        groups[areaUpper] = [];
      }
      groups[areaUpper].push(exam);
    });

    return groups;
  }, [exams, examSearchQuery]);

  // Toggle selection of exam
  const handleToggleExam = (code: string) => {
    setSelectedExamCodes(prev => 
      prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]
    );
  };

  // Pricing calculations
  const calculatedPricing = useMemo(() => {
    const list = selectedExamCodes.map(code => {
      const exam = exams.find(e => e.code === code);
      const originalPrice = exam ? exam.price : 0;
      // If Convenio Doctor SV is active, the price is $0.00
      const activePrice = isConvenioDoctorSV ? 0 : originalPrice;
      return {
        code,
        name: exam ? exam.name : 'Prueba',
        price: activePrice,
        originalPrice
      };
    });

    const subtotal = list.reduce((sum, item) => sum + item.originalPrice, 0);
    const total = list.reduce((sum, item) => sum + item.price, 0);
    const discount = subtotal - total;

    return {
      list,
      subtotal,
      total,
      discount
    };
  }, [selectedExamCodes, exams, isConvenioDoctorSV]);

  // Handle final submission of Patient & Order
  const handleRegisterOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientName.trim()) {
      alert('Por favor ingrese el Nombre Completo del Paciente.');
      return;
    }
    if (selectedExamCodes.length === 0) {
      alert('Por favor seleccione al menos un examen para la orden.');
      return;
    }

    // 1. Identify or register patient
    let patientObj: Patient;

    if (selectedPatientId) {
      // Use existing patient
      const found = patients.find(p => p.id === selectedPatientId);
      if (found) {
        patientObj = found;
      } else {
        // Fallback
        patientObj = {
          id: selectedPatientId,
          name: patientName.trim(),
          dui: patientDui.trim() || 'N/A',
          phone: patientPhone.trim() || 'N/A',
          birthDate: patientBirthDate,
          gender: patientGender,
          email: patientEmail.trim(),
          createdAt: new Date().toISOString()
        };
      }
    } else {
      // Create and register a new patient
      const nextId = `PAT-${1000 + patients.length + 1}`;
      patientObj = {
        id: nextId,
        name: patientName.trim(),
        dui: patientDui.trim() || 'N/A',
        phone: patientPhone.trim() || 'N/A',
        birthDate: patientBirthDate,
        gender: patientGender,
        email: patientEmail.trim(),
        createdAt: new Date().toISOString()
      };
      onAddPatient(patientObj);
      onAddAuditLog(
        'Registrar Paciente', 
        `Registró al paciente ${patientObj.name} (DUI: ${patientObj.dui}, ID: ${patientObj.id}) durante la recepción.`
      );
    }

    // 2. Create the order object
    const birthYear = new Date(patientBirthDate).getFullYear();
    const currentYear = new Date().getFullYear();
    const patientAge = currentYear - birthYear;
    const orderYear = new Date().getFullYear();
    const orderNum = `ORD-${orderYear}-${String(Math.floor(1000 + Math.random() * 9000))}`;

    const newOrder: Order = {
      orderNumber: orderNum,
      patientId: patientObj.id,
      patientName: patientObj.name,
      patientAge: patientAge > 0 ? patientAge : 0,
      patientGender: patientObj.gender,
      doctorName: doctorName.trim() || 'SOLICITANTE PARTICULAR',
      // If marked urgent, we can save it in status or handle it
      status: 'Pendiente', 
      paymentStatus: isConvenioDoctorSV ? 'Exento' : 'Pagado',
      examCodes: selectedExamCodes,
      createdAt: new Date(`${examDate}T${new Date().toLocaleTimeString('es-SV', { hour12: false })}`).toISOString(),
      totalAmount: calculatedPricing.total
    };

    // If marked urgent, keep track of this in the logs and save
    onCreateOrder(newOrder);
    onAddAuditLog(
      'Crear Orden', 
      `Creó la orden ${newOrder.orderNumber} para el paciente ${newOrder.patientName} (${selectedExamCodes.length} exámenes)${isConvenioDoctorSV ? ' [CONVENIO DOCTOR SV]' : ''}${isUrgente ? ' [URGENTE]' : ''}`
    );

    // Trigger printable tags window
    setCreatedOrderForTags(newOrder);

    // Reset admission desk fields
    handleClearPatientForm();
    setSelectedExamCodes([]);
    setDoctorName('SOLICITANTE PARTICULAR');
    setIsConvenioDoctorSV(false);
    setIsUrgente(false);
    setExamDate(new Date().toISOString().split('T')[0]);
  };

  return (
    <div className="space-y-4">
      {/* Title Header */}
      <div className="bg-white border border-slate-200 px-4 py-3 rounded-lg flex flex-col md:flex-row md:items-center justify-between shadow-xs">
        <div>
          <h1 className="text-base font-black text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-blue-600 rounded-full"></span>
            Recepción y Admisión de Pacientes
          </h1>
          <p className="text-[11px] text-slate-500 mt-0.5 font-medium">
            Módulo simplificado para la facturación, ingreso de órdenes, convenios de cortesía y viñetas de laboratorio.
          </p>
        </div>
        
        {/* Quick Patient Search Input */}
        <div className="relative mt-2 md:mt-0 w-full md:w-80">
          <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
          <input
            id="p_admission_lookup"
            type="text"
            placeholder="🔍 Buscar paciente existente para auto-llenar..."
            className="w-full pl-8 pr-4 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 font-medium text-slate-800 placeholder-slate-400"
            value={patientSearch}
            onChange={(e) => setPatientSearch(e.target.value)}
          />

          {/* Matches Dropdown */}
          {patientSearch && (
            <div className="absolute right-0 mt-1 w-full bg-white border border-slate-200 rounded-md shadow-lg max-h-48 overflow-y-auto divide-y divide-slate-100 z-50">
              {matchedPatients.length > 0 ? (
                matchedPatients.map(p => (
                  <button
                    key={p.id}
                    onClick={() => handleSelectExistingPatient(p)}
                    className="w-full text-left px-3 py-2 hover:bg-blue-50/50 flex justify-between items-center transition-colors cursor-pointer text-xs"
                  >
                    <div>
                      <div className="font-bold text-slate-800">{p.name}</div>
                      <div className="text-[10px] text-slate-400">DUI: {p.dui} • Tel: {p.phone}</div>
                    </div>
                    <span className="text-[9px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-mono font-bold">
                      {p.id}
                    </span>
                  </button>
                ))
              ) : (
                <div className="p-2.5 text-[10px] text-slate-400 text-center font-medium">
                  No se encontraron coincidencias. Puede registrar el paciente escribiendo abajo.
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Grid split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        
        {/* Left Panel: INFORMACIÓN GENERAL DEL PACIENTE */}
        <form onSubmit={handleRegisterOrder} className="lg:col-span-5 space-y-4">
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            <div className="flex justify-between items-center border-b border-slate-150 pb-2.5">
              <h2 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-4 h-4 text-blue-600" />
                Información General del Paciente
              </h2>
              {selectedPatientId && (
                <button
                  type="button"
                  onClick={handleClearPatientForm}
                  className="text-[9px] bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-700 px-2 py-0.5 rounded font-bold transition-colors cursor-pointer"
                >
                  Nuevo Paciente
                </button>
              )}
            </div>

            {selectedPatientId && (
              <div className="p-2 bg-blue-50 text-blue-800 text-[10px] font-bold rounded border border-blue-100 flex items-center justify-between">
                <span>✓ Paciente Existente Cargado ({selectedPatientId})</span>
                <span className="text-[9px] bg-blue-200 text-blue-900 px-1 py-0.5 rounded">HISTORIAL COMPLETO</span>
              </div>
            )}

            {/* Form Fields */}
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">Nombre Completo del Paciente *</label>
                <input
                  id="patient_fullname_input"
                  type="text"
                  required
                  placeholder="Ej. Carlos Alberto Rodríguez Alvarado"
                  className="w-full px-3 py-2 text-xs bg-slate-50/50 border border-slate-250 rounded focus:outline-hidden focus:border-blue-500 font-bold text-slate-800 placeholder-slate-400"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">DUI / Cédula / ID</label>
                  <input
                    id="patient_dui_input"
                    type="text"
                    placeholder="N/A"
                    className="w-full px-3 py-2 text-xs font-mono bg-slate-50/50 border border-slate-250 rounded focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={patientDui}
                    onChange={(e) => setPatientDui(formatDui(e.target.value))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">Fecha de Nacimiento *</label>
                  <input
                    id="patient_birth_input"
                    type="date"
                    required
                    className="w-full px-3 py-2 text-xs bg-slate-50/50 border border-slate-250 rounded focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                    value={patientBirthDate}
                    onChange={(e) => setPatientBirthDate(e.target.value)}
                  />
                </div>
              </div>

              {/* Sex Tabs Selection - High visibility buttons matching screenshots */}
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1.5 uppercase tracking-wide">Sexo (Género Clínico) *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPatientGender('M')}
                    className={`py-2 px-3 text-xs font-bold rounded border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      patientGender === 'M'
                        ? 'bg-blue-50 border-blue-500 text-blue-700 ring-2 ring-blue-500/10'
                        : 'bg-white border-slate-250 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>Masculino</span>
                    <span>👦</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPatientGender('F')}
                    className={`py-2 px-3 text-xs font-bold rounded border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      patientGender === 'F'
                        ? 'bg-purple-50 border-purple-500 text-purple-700 ring-2 ring-purple-500/10'
                        : 'bg-white border-slate-250 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>Femenino</span>
                    <span>👧</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">Número Telefónico / WhatsApp</label>
                  <input
                    id="patient_phone_input"
                    type="text"
                    placeholder="Ej. 7700-1122"
                    className="w-full px-3 py-2 text-xs font-mono bg-slate-50/50 border border-slate-250 rounded focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(formatPhone(e.target.value))}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">Correo Electrónico</label>
                  <input
                    id="patient_email_input"
                    type="email"
                    placeholder="Ej. paciente@gmail.com"
                    className="w-full px-3 py-2 text-xs bg-slate-50/50 border border-slate-250 rounded focus:outline-hidden focus:border-blue-500 text-slate-800"
                    value={patientEmail}
                    onChange={(e) => setPatientEmail(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">Médico Solicitante / Solicitud Particular</label>
                <input
                  id="doctor_solicitor_input"
                  type="text"
                  placeholder="SOLICITANTE PARTICULAR"
                  className="w-full px-3 py-2 text-xs bg-slate-50/50 border border-slate-250 rounded focus:outline-hidden focus:border-blue-500 font-bold text-slate-800"
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">Fecha del Examen</label>
                <input
                  id="exam_date_input"
                  type="date"
                  className="w-full px-3 py-2 text-xs bg-slate-50/50 border border-slate-250 rounded focus:outline-hidden focus:border-blue-500 text-slate-700 font-bold"
                  value={examDate}
                  onChange={(e) => setExamDate(e.target.value)}
                />
              </div>
            </div>

            {/* Special Toggles matching screenshot */}
            <div className="space-y-2.5 pt-2 border-t border-slate-150">
              
              {/* Convenio Doctor SV */}
              <label className="relative flex items-start gap-3 p-3 bg-indigo-50/35 border border-indigo-100 hover:bg-indigo-50/70 rounded-md cursor-pointer transition-colors">
                <input
                  id="convenio_drsv_checkbox"
                  type="checkbox"
                  className="mt-0.5 w-4 h-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500"
                  checked={isConvenioDoctorSV}
                  onChange={(e) => setIsConvenioDoctorSV(e.target.checked)}
                />
                <div className="text-xs">
                  <span className="font-extrabold text-indigo-900 block flex items-center gap-1">
                    ✨ Opción Especial: Convenio Doctor SV
                  </span>
                  <p className="text-[10px] text-indigo-600 mt-0.5 font-medium">
                    Seleccione esta opción para registrar la orden bajo el convenio de cortesía de Doctor SV. Todos los exámenes seleccionados se computarán automáticamente a <strong>$0.00 USD</strong>.
                  </p>
                </div>
              </label>

              {/* Urgente */}
              <label className="relative flex items-start gap-3 p-3 bg-orange-50/35 border border-orange-100 hover:bg-orange-50/70 rounded-md cursor-pointer transition-colors">
                <input
                  id="urgente_checkbox"
                  type="checkbox"
                  className="mt-0.5 w-4 h-4 text-orange-600 border-slate-300 rounded focus:ring-orange-500"
                  checked={isUrgente}
                  onChange={(e) => setIsUrgente(e.target.checked)}
                />
                <div className="text-xs">
                  <span className="font-extrabold text-orange-950 block flex items-center gap-1">
                    ⚠️ Marcar Orden como 'Urgente' ⏱️
                  </span>
                  <p className="text-[10px] text-orange-600 mt-0.5 font-medium">
                    Habilite esta casilla si el paciente requiere prioridad en la entrega. Resalta la orden con color naranja brillante en el tablero de trabajo.
                  </p>
                </div>
              </label>
            </div>
          </div>
        </form>

        {/* Right Panel: CATÁLOGO DE EXÁMENES */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
            
            <div className="flex justify-between items-center border-b border-slate-150 pb-2.5">
              <div className="flex items-center gap-2">
                <h2 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                  Catálogo de Exámenes
                </h2>
                <span className="bg-purple-100 text-purple-700 font-extrabold text-[9px] px-2 py-0.5 rounded-full">
                  {exams.length} EXÁMENES
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 font-medium">
              Marque cada uno de los exámenes solicitados en la orden. Utilice el buscador para localizarlo por nombre o especialidad.
            </p>

            {/* Exam search input */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                id="exam_catalog_search"
                type="text"
                placeholder="🔍 Buscar examen o categoría..."
                className="w-full pl-8 pr-4 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-800 font-medium placeholder-slate-400"
                value={examSearchQuery}
                onChange={(e) => setExamSearchQuery(e.target.value)}
              />
            </div>

            {/* Scrollable Grouped Exams List */}
            <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
              {Object.keys(groupedExams).length > 0 ? (
                Object.keys(groupedExams).map(area => {
                  const areaExams = groupedExams[area];
                  return (
                    <div key={area} className="space-y-2">
                      {/* Section header in colored theme bar */}
                      <div className="bg-[#EEF2F6] text-slate-700 text-[10px] font-black px-2.5 py-1 rounded border border-slate-250 uppercase tracking-wider">
                        {area}
                      </div>

                      {/* Exams list */}
                      <div className="grid grid-cols-1 gap-1.5">
                        {areaExams.map(exam => {
                          const isSelected = selectedExamCodes.includes(exam.code);
                          return (
                            <label
                              key={exam.code}
                              className={`flex items-center justify-between p-2.5 rounded border transition-all text-xs cursor-pointer ${
                                isSelected 
                                  ? 'bg-blue-50/55 border-blue-400 font-bold text-blue-900 shadow-3xs' 
                                  : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                              }`}
                            >
                              <div className="flex items-center gap-2.5">
                                <input
                                  type="checkbox"
                                  className="w-3.5 h-3.5 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                                  checked={isSelected}
                                  onChange={() => handleToggleExam(exam.code)}
                                />
                                <div className="space-y-0.5">
                                  <div className="text-xs font-bold text-slate-900 leading-tight">{exam.name}</div>
                                  <div className="text-[9px] text-slate-400 font-medium">Método: {exam.method} • {exam.deliveryTime}</div>
                                </div>
                              </div>
                              <div className="text-right flex items-center gap-2 font-mono font-bold text-xs text-slate-900">
                                {isConvenioDoctorSV ? (
                                  <>
                                    <span className="line-through text-slate-400 text-[10px]">${exam.price.toFixed(2)}</span>
                                    <span className="text-emerald-600">$0.00</span>
                                  </>
                                ) : (
                                  <span>${exam.price.toFixed(2)}</span>
                                )}
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-12 text-slate-400 font-medium text-xs">
                  No se encontraron exámenes con su búsqueda.
                </div>
              )}
            </div>

            {/* Summary Block: RESUMEN DE ARANCEL EN TAQUILLA */}
            <div className="border-t border-slate-200 pt-4 space-y-3">
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wide">
                Resumen de Arancel en Taquilla
              </h3>

              {selectedExamCodes.length > 0 ? (
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-3.5">
                  <div className="divide-y divide-slate-100 max-h-40 overflow-y-auto space-y-1 pr-1">
                    {calculatedPricing.list.map(item => (
                      <div key={item.code} className="flex justify-between text-xs py-1.5 font-medium">
                        <span className="text-slate-700 truncate pr-2">✓ {item.name}</span>
                        <div className="text-right shrink-0">
                          {isConvenioDoctorSV ? (
                            <span className="font-mono text-slate-400 line-through text-[10px] mr-2">${item.originalPrice.toFixed(2)}</span>
                          ) : null}
                          <span className="font-mono font-bold text-slate-900">${item.price.toFixed(2)}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-200 space-y-1.5 text-xs">
                    {isConvenioDoctorSV && (
                      <div className="flex justify-between font-bold text-indigo-700 text-[11px] bg-indigo-50 px-2 py-1 rounded">
                        <span>Convenio Cortesia Dr. SV</span>
                        <span>-${calculatedPricing.discount.toFixed(2)} USD</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center text-slate-700 font-medium">
                      <span>Subtotal de Aranceles:</span>
                      <span className="font-mono font-bold">${calculatedPricing.subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm font-black text-slate-900 pt-1.5 border-t border-dashed border-slate-250">
                      <span>Total Neto a Cobrar (USD):</span>
                      <span className="font-mono text-emerald-600 text-base">${calculatedPricing.total.toFixed(2)}</span>
                    </div>
                  </div>

                  <button
                    id="btn_reception_register_order"
                    type="submit"
                    onClick={handleRegisterOrder}
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <ShoppingBag className="w-4 h-4" /> Registrar Ingreso de Orden y Generar Viñetas
                  </button>
                </div>
              ) : (
                <div className="bg-slate-50/70 p-6 rounded-lg text-center border border-dashed border-slate-200 text-xs text-slate-400 font-medium">
                  No hay exámenes seleccionados para la orden.
                </div>
              )}

            </div>

          </div>
        </div>

      </div>

      {/* Printable Clinical Labels / Viñetas Modal */}
      {createdOrderForTags && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-5 space-y-4 border border-slate-200">
            <div className="flex justify-between items-center pb-2 border-b border-slate-150">
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                <Printer className="w-4.5 h-4.5 text-blue-600 animate-pulse" />
                Viñetas de Identificación de Muestras
              </h3>
              <button 
                id="close_tags_modal"
                onClick={() => setCreatedOrderForTags(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <p className="text-[11px] text-slate-500 font-medium">
              Etiquetas térmicas automáticas de tubos y frascos de laboratorio generadas por el LIS para la orden <strong className="font-mono text-slate-800">{createdOrderForTags.orderNumber}</strong>.
            </p>

            {/* Generated Clinical Tags container */}
            <div className="space-y-3 max-h-80 overflow-y-auto p-1 bg-slate-50 rounded border border-slate-200">
              {createdOrderForTags.examCodes.map((code, idx) => {
                const exam = exams.find(e => e.code === code);
                return (
                  <div key={idx} className="bg-white p-3 border-2 border-dashed border-slate-400 rounded shadow-2xs font-mono text-[10px] space-y-1 text-slate-800">
                    <div className="flex justify-between font-bold border-b border-slate-100 pb-1">
                      <span>LAB. TORRES SV</span>
                      <span className="text-[9px] bg-slate-100 px-1 rounded">{exam?.area || 'GENERAL'}</span>
                    </div>
                    <div className="font-bold text-slate-950 text-xs truncate mt-1">
                      {createdOrderForTags.patientName}
                    </div>
                    <div className="flex justify-between text-slate-500 font-medium">
                      <span>EDAD: {createdOrderForTags.patientAge} años • {createdOrderForTags.patientGender === 'M' ? 'MASC' : 'FEM'}</span>
                      <span>{new Date(createdOrderForTags.createdAt).toLocaleDateString('es-SV')}</span>
                    </div>
                    <div className="font-bold text-blue-700 bg-blue-50 p-1 rounded text-center truncate mt-1.5 border border-blue-100 text-xs">
                      {exam?.name || 'Prueba'}
                    </div>
                    
                    {/* Simulated barcode graphic */}
                    <div className="pt-2 flex flex-col items-center">
                      <div className="w-full h-8 bg-slate-950 flex gap-0.5 justify-center overflow-hidden">
                        {[...Array(28)].map((_, bIdx) => {
                          const widths = ['w-0.5', 'w-1', 'w-[1.5px]', 'w-[2px]'];
                          const w = widths[(idx + bIdx) % widths.length];
                          const visible = (bIdx * 3 + idx * 7) % 11 > 2;
                          return visible ? <div key={bIdx} className={`h-full ${w} bg-white`} /> : <div key={bIdx} className="h-full w-0.5 bg-slate-950" />;
                        })}
                      </div>
                      <span className="text-[8px] text-slate-450 tracking-widest mt-1 font-bold">
                        *{createdOrderForTags.orderNumber}*{code}*
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex gap-2 justify-end pt-2 border-t border-slate-150">
              <button
                id="btn_modal_print_tags"
                onClick={() => {
                  alert('Comando de impresión enviado a la ticketera de viñetas térmicas.');
                  setCreatedOrderForTags(null);
                }}
                className="px-4 py-2 bg-slate-900 hover:bg-black text-white font-extrabold text-xs uppercase tracking-wide rounded-md transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" /> Imprimir Viñetas
              </button>
              <button
                id="btn_modal_close_tags"
                onClick={() => setCreatedOrderForTags(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-md transition-colors cursor-pointer"
              >
                Cerrar Ventana
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
