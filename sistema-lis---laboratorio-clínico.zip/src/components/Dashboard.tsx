/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Users, 
  FileText, 
  DollarSign, 
  Activity, 
  CheckCircle, 
  Clock, 
  ShieldAlert 
} from 'lucide-react';
import { Patient, Order, ExamResult, AuditLog } from '../types/lis';

interface DashboardProps {
  patients: Patient[];
  orders: Order[];
  results: ExamResult[];
  auditLogs: AuditLog[];
  onNavigate: (view: string) => void;
  onSelectOrder: (order: Order) => void;
}

export default function Dashboard({ 
  patients, 
  orders, 
  results, 
  auditLogs, 
  onNavigate,
  onSelectOrder
}: DashboardProps) {
  // Calculations
  const totalPatients = patients.length;
  const totalOrders = orders.length;
  
  // Pending results
  const pendingOrders = orders.filter(o => o.status === 'Pendiente').length;
  const completedOrders = orders.filter(o => o.status === 'Completado').length;
  const validatedOrders = orders.filter(o => o.status === 'Validado').length;

  // Earnings
  const totalEarnings = orders
    .filter(o => o.paymentStatus === 'Pagado')
    .reduce((sum, o) => sum + o.totalAmount, 0);

  // Quick stats by area
  const areaDistribution = [
    { name: 'Hematología', count: 12, percentage: 35, color: 'bg-red-500' },
    { name: 'Química Clínica', count: 15, percentage: 44, color: 'bg-blue-500' },
    { name: 'Uroanálisis', count: 4, percentage: 12, color: 'bg-yellow-500' },
    { name: 'Coprología', count: 2, percentage: 6, color: 'bg-green-500' },
    { name: 'Inmunología', count: 1, percentage: 3, color: 'bg-purple-500' },
  ];

  return (
    <div className="space-y-4">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-slate-900 text-white px-5 py-3.5 rounded-lg border border-slate-800 shadow-xs">
        <div>
          <h1 className="text-lg font-sans font-bold tracking-tight">Panel de Control LIS • BioLab El Salvador</h1>
          <p className="text-slate-300 text-xs mt-0.5">
            Sistema Integrado de Control de Exámenes, Resultados y Viñetas Clínicas
          </p>
        </div>
        <div className="mt-3 md:mt-0 flex gap-2">
          <button 
            id="dash_btn_recep"
            onClick={() => onNavigate('recepcion')}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Users className="w-3.5 h-3.5" /> Nueva Recepción
          </button>
          <button 
            id="dash_btn_results"
            onClick={() => onNavigate('resultados')}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-md transition-colors border border-slate-750 flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" /> Ingresar Resultados
          </button>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1 */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 flex flex-col justify-between shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Pacientes Registrados</span>
            <span className="p-1.5 bg-blue-50 text-blue-600 rounded-md">
              <Users className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2.5 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-sans text-slate-900 tracking-tight">{totalPatients}</span>
            <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">Activo</span>
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 flex flex-col justify-between shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Órdenes Pendientes</span>
            <span className="p-1.5 bg-amber-50 text-amber-600 rounded-md">
              <Clock className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2.5 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-sans text-slate-900 tracking-tight">{pendingOrders}</span>
            <span className="text-[10px] text-amber-700 font-bold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
              {completedOrders} Listas
            </span>
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 flex flex-col justify-between shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Órdenes Validadas</span>
            <span className="p-1.5 bg-emerald-50 text-emerald-600 rounded-md">
              <CheckCircle className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2.5 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-sans text-slate-900 tracking-tight">{validatedOrders}</span>
            <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">Firmado</span>
          </div>
        </div>

        {/* Card 4 */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 flex flex-col justify-between shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Ingresos Facturados</span>
            <span className="p-1.5 bg-violet-50 text-violet-600 rounded-md">
              <DollarSign className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2.5 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 tracking-tight">${totalEarnings.toFixed(2)}</span>
            <span className="text-[10px] text-slate-400 font-medium">Exento excl.</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Active Orders List */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs lg:col-span-2">
          <div className="flex items-center justify-between mb-3.5">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Actividad Reciente de Órdenes</h2>
            <button 
              id="dash_nav_orders"
              onClick={() => onNavigate('resultados')}
              className="text-xs text-blue-600 hover:text-blue-800 font-bold cursor-pointer"
            >
              Ver todas →
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider bg-slate-50/70">
                  <th className="py-2 px-2.5">Código Orden</th>
                  <th className="py-2 px-2.5">Paciente</th>
                  <th className="py-2 px-2.5">Fecha / Hora</th>
                  <th className="py-2 px-2.5 text-center">Pago</th>
                  <th className="py-2 px-2.5 text-center">Estado LIS</th>
                  <th className="py-2 px-2.5 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.slice().reverse().map((order) => (
                  <tr key={order.orderNumber} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-2 px-2.5 font-mono text-[11px] font-bold text-slate-700">
                      {order.orderNumber}
                    </td>
                    <td className="py-2 px-2.5">
                      <div className="font-bold text-slate-900">{order.patientName}</div>
                      <div className="text-[10px] text-slate-400">{order.patientAge} años • {order.patientGender === 'M' ? 'Masculino' : 'Femenino'}</div>
                    </td>
                    <td className="py-2 px-2.5 text-slate-500 text-[11px]">
                      {new Date(order.createdAt).toLocaleString('es-SV', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                    <td className="py-2 px-2.5 text-center">
                      <span className={`inline-flex px-1.5 py-0.5 text-[10px] font-bold rounded ${
                        order.paymentStatus === 'Pagado' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                        order.paymentStatus === 'Pendiente' ? 'bg-amber-50 text-amber-700 border border-amber-100' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {order.paymentStatus}
                      </span>
                    </td>
                    <td className="py-2 px-2.5 text-center">
                      <span className={`inline-flex px-1.5 py-0.5 text-[10px] font-bold rounded ${
                        order.status === 'Validado' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                        order.status === 'Completado' ? 'bg-blue-50 text-blue-800 border border-blue-200' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="py-2 px-2.5 text-right">
                      <button
                        id={`dash_btn_view_` + order.orderNumber}
                        onClick={() => {
                          onSelectOrder(order);
                          onNavigate('reportes');
                        }}
                        className="text-[11px] text-blue-600 hover:text-blue-800 font-extrabold px-2 py-0.5 rounded hover:bg-blue-50 transition-colors cursor-pointer border border-transparent hover:border-blue-100"
                      >
                        {order.status === 'Validado' ? 'Ver PDF' : 'Editar'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Areas / Volume & Audit Logs Side column */}
        <div className="space-y-4">
          {/* Areas Distribution Card */}
          <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-blue-600" />
              Exámenes por Área Clínica
            </h2>
            <div className="space-y-3">
              {areaDistribution.map((area) => (
                <div key={area.name}>
                  <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                    <span>{area.name}</span>
                    <span className="font-mono text-slate-500">{area.count} ({area.percentage}%)</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className={`${area.color} h-full rounded-full`}
                      style={{ width: `${area.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Real-time Audit Logs Stream */}
          <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-red-600" />
              Auditoría del Sistema
            </h2>
            <div className="space-y-2.5 max-h-52 overflow-y-auto pr-1">
              {auditLogs.slice(0, 5).map((log) => (
                <div key={log.id} className="text-[11px] border-l-2 border-slate-200 pl-2.5 py-0.5 space-y-0.5">
                  <div className="flex justify-between text-slate-400">
                    <span className="font-bold text-slate-600">{log.username} ({log.role})</span>
                    <span className="font-mono text-[10px]">{new Date(log.timestamp).toLocaleTimeString('es-SV', { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="text-slate-800 font-bold text-[11px]">{log.action}</p>
                  <p className="text-slate-500 text-[10px] leading-relaxed">{log.details}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
