/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  CheckCircle2, 
  Clock, 
  Search, 
  User, 
  Award, 
  ArrowLeft,
  X
} from 'lucide-react';
import jsPDF from 'jspdf';
import { Order, Exam, ExamResult, ReferenceRange, Patient, LetterheadConfig } from '../types/lis';

interface ReportsProps {
  orders: Order[];
  exams: Exam[];
  results: ExamResult[];
  referenceRanges: ReferenceRange[];
  patients: Patient[];
  selectedOrder: Order | null;
  onSelectOrder: (order: Order | null) => void;
  onAddAuditLog: (action: string, details: string) => void;
  letterhead: LetterheadConfig;
}

export default function Reports({ 
  orders, 
  exams, 
  results, 
  referenceRanges, 
  patients,
  selectedOrder,
  onSelectOrder,
  onAddAuditLog,
  letterhead
}: ReportsProps) {
  const [searchQuery, setSearchQuery] = useState('');

  // Filter only completed or validated orders for report generation
  const reportReadyOrders = useMemo(() => {
    return orders.filter(o => 
      (o.status === 'Completado' || o.status === 'Validado') &&
      (o.patientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
       o.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [orders, searchQuery]);

  // Find patient record
  const selectedPatientRecord = useMemo(() => {
    if (!selectedOrder) return null;
    return patients.find(p => p.id === selectedOrder.patientId) || null;
  }, [selectedOrder, patients]);

  // Find reference range
  const findReferenceRange = (examCode: string, age: number, sex: 'M' | 'F' | 'Otro'): ReferenceRange | null => {
    const normalizedSex = (sex === 'M' || sex === 'F') ? sex : 'Todos';
    const candidates = referenceRanges.filter(r => r.examCode === examCode);
    let ageMatch = candidates.filter(r => age >= r.ageMin && age <= r.ageMax);
    let sexMatch = ageMatch.filter(r => r.sex === normalizedSex || r.sex === 'Todos');
    
    if (sexMatch.length > 0) return sexMatch[0];
    if (ageMatch.length > 0) return ageMatch[0];
    if (candidates.length > 0) return candidates[0];
    
    return null;
  };

  const renderStructuredPreview = (code: string, value: string) => {
    try {
      if (!value || !value.startsWith('{')) {
        return <span className="font-bold text-slate-800">{value || 'Pendiente'}</span>;
      }
      const data = JSON.parse(value);
      
      if (code === 'HEM01') {
        const rows = [
          { name: 'Glóbulos Rojos', val: data.globulosRojos, unit: 'M/µL', ref: '4.5 - 5.9 (H) | 4.0 - 5.2 (M)' },
          { name: 'Hemoglobina', val: data.hemoglobina, unit: 'g/dL', ref: '13.8 - 17.2 (H) | 12.1 - 15.1 (M)' },
          { name: 'Hematocrito', val: data.hematocrito, unit: '%', ref: '41 - 50 (H) | 36 - 46 (M)' },
          { name: 'VCM', val: data.vcm, unit: 'fL', ref: '80 - 100' },
          { name: 'HCM', val: data.hcm, unit: 'pg', ref: '27 - 33' },
          { name: 'CHCM', val: data.chcm, unit: 'g/dL', ref: '32 - 36' },
          { name: 'RDW', val: data.rdw, unit: '%', ref: '11.5 - 14.5' },
          { name: 'Plaquetas', val: data.plaquetas, unit: '/µL', ref: '150,000 - 450,000' },
          { name: 'VPM', val: data.vpm, unit: 'fL', ref: '7.4 - 10.4' },
          { name: 'Leucocitos', val: data.globulosBlancos, unit: '/µL', ref: '4,500 - 11,000' },
          { name: 'Neutrófilos', val: data.neutrofilos, unit: '%', ref: '40 - 70' },
          { name: 'Linfocitos', val: data.linfocitos, unit: '%', ref: '20 - 45' },
          { name: 'Monocitos', val: data.monocitos, unit: '%', ref: '2 - 10' },
          { name: 'Eosinófilos', val: data.eosinofilos, unit: '%', ref: '1 - 6' },
          { name: 'Basófilos', val: data.basofilos, unit: '%', ref: '0 - 2' }
        ];
        return (
          <div className="w-full max-w-lg border border-slate-200 rounded-md overflow-hidden bg-slate-50 p-2 space-y-1 mt-1">
            <div className="grid grid-cols-3 text-[9px] font-black text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-200">
              <span>Parámetro</span>
              <span className="text-center">Resultado</span>
              <span className="text-right">Referencia</span>
            </div>
            {rows.map((r, i) => (
              <div key={i} className="grid grid-cols-3 text-[10px] py-0.5 border-b border-slate-100/50 last:border-0 font-medium">
                <span className="text-slate-600 font-bold">{r.name}</span>
                <span className="text-center font-mono font-extrabold text-slate-900">{r.val || '-'} <span className="text-[8px] text-slate-400">{r.unit}</span></span>
                <span className="text-right font-mono text-slate-500 text-[9px]">{r.ref}</span>
              </div>
            ))}
          </div>
        );
      }

      if (code === 'EGO01') {
        const rows = [
          { name: 'Color', val: data.color, ref: 'Amarillo' },
          { name: 'Aspecto', val: data.aspecto, ref: 'Limpio' },
          { name: 'Densidad', val: data.densidad, ref: '1.005 - 1.030' },
          { name: 'pH', val: data.ph, ref: '5.0 - 7.5' },
          { name: 'Proteínas', val: data.proteinas, ref: 'Negativo' },
          { name: 'Glucosa', val: data.glucosa, ref: 'Negativo' },
          { name: 'Cetonas', val: data.cetonas, ref: 'Negativo' },
          { name: 'Bilirrubina', val: data.bilirrubina, ref: 'Negativo' },
          { name: 'Urobilinógeno', val: data.urobilinogeno, ref: 'Normal' },
          { name: 'Sangre Oculta', val: data.sangreOculta, ref: 'Negativo' },
          { name: 'Nitritos', val: data.nitritos, ref: 'Negativo' },
          { name: 'Est. Leucocitaria', val: data.leucocitosQuimico, ref: 'Negativo' },
          { name: 'Leucocitos (Campo)', val: data.leucocitosSedimento, ref: '0 - 5' },
          { name: 'Hematíes (Campo)', val: data.hematies, ref: '0 - 2' },
          { name: 'Cel. Epiteliales', val: data.celulasEpiteliales, ref: 'Escasas' },
          { name: 'Bacterias', val: data.bacterias, ref: 'Escasas' },
          { name: 'Cristales', val: data.cristales, ref: 'No se observan' },
          { name: 'Cilindros', val: data.cilindros, ref: 'No se observan' },
          { name: 'Filamento Mucoide', val: data.filamentoMucoide, ref: 'Escaso' },
          { name: 'Levaduras', val: data.levaduras, ref: 'No se observan' }
        ];
        return (
          <div className="w-full max-w-lg border border-slate-200 rounded-md overflow-hidden bg-slate-50 p-2 space-y-1 mt-1">
            <div className="grid grid-cols-3 text-[9px] font-black text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-200">
              <span>Parámetro</span>
              <span className="text-center">Resultado</span>
              <span className="text-right">Referencia</span>
            </div>
            {rows.map((r, i) => (
              <div key={i} className="grid grid-cols-3 text-[10px] py-0.5 border-b border-slate-100/50 last:border-0 font-medium">
                <span className="text-slate-600 font-bold">{r.name}</span>
                <span className="text-center font-extrabold text-slate-900">{r.val || '-'}</span>
                <span className="text-right font-mono text-slate-500 text-[9px]">{r.ref}</span>
              </div>
            ))}
          </div>
        );
      }

      if (code === 'EGC01' || code === 'EGH01') {
        const rows = [
          { name: 'Color', val: data.color, ref: 'Café' },
          { name: 'Consistencia', val: data.consistencia, ref: 'Pastosa' },
          { name: 'Moco Fecal', val: data.moco, ref: 'Negativo' },
          { name: 'Sangre Macro.', val: data.sangreMacroscopico, ref: 'Negativo' },
          { name: 'Leucocitos (Campo)', val: data.leucocitos, ref: '0-2' },
          { name: 'Hematíes (Campo)', val: data.hematies, ref: '0-1' },
          { name: 'Levaduras', val: data.levaduras, ref: 'No se observan' },
          { name: 'Fibras Alimenticias', val: data.fibrasAlimenticias, ref: 'Escasas' },
          { name: 'Almidones', val: data.almidones, ref: 'No se observan' },
          { name: 'Grasas', val: data.grasas, ref: 'No se observan' },
          { name: 'Quistes Ameba', val: data.quistesAmeba, ref: 'No se observan' },
          { name: 'Trofozoítos', val: data.trofozoitos, ref: 'No se observan' },
          { name: 'Huevos Helmintos', val: data.huevosHelmintos, ref: 'No se observan' },
          { name: 'Larvas', val: data.larvas, ref: 'No se observan' }
        ];
        return (
          <div className="w-full max-w-lg border border-slate-200 rounded-md overflow-hidden bg-slate-50 p-2 space-y-1 mt-1">
            <div className="grid grid-cols-3 text-[9px] font-black text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-200">
              <span>Parámetro</span>
              <span className="text-center">Resultado</span>
              <span className="text-right">Referencia</span>
            </div>
            {rows.map((r, i) => (
              <div key={i} className="grid grid-cols-3 text-[10px] py-0.5 border-b border-slate-100/50 last:border-0 font-medium">
                <span className="text-slate-600 font-bold">{r.name}</span>
                <span className="text-center font-extrabold text-slate-900">{r.val || '-'}</span>
                <span className="text-right font-mono text-slate-500 text-[9px]">{r.ref}</span>
              </div>
            ))}
          </div>
        );
      }
    } catch (e) {
      return <span className="text-red-500 font-bold">Error parseando JSON</span>;
    }
    return <span className="font-bold text-slate-800">{value}</span>;
  };

  // Compile PDF report with jsPDF
  const handleDownloadPdf = () => {
    if (!selectedOrder || !selectedPatientRecord) return;

    try {
      const doc = new jsPDF();
      const orderNum = selectedOrder.orderNumber;
      
      const primaryColor = [15, 23, 42]; // slate-900
      const secondaryColor = [71, 85, 105]; // slate-600
      const lightGray = [241, 245, 249]; // slate-100
      
      // Draw Header Letterhead
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(0, 0, 210, 38, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(14);
      doc.text(letterhead.labName.toUpperCase(), 14, 13);
      
      doc.setFont('Helvetica', 'normal');
      doc.setFontSize(8);
      doc.text(`${letterhead.slogan}  |  Reg: ${letterhead.cssp}`, 14, 19);
      doc.text(`Dir: ${letterhead.address}`, 14, 24);
      doc.text(`Tels: ${letterhead.phoneLandline} / ${letterhead.phoneCell}  |  Responsable: ${letterhead.ownerName} (${letterhead.jvplc})`, 14, 29);
      doc.text("SISTEMA DE INFORMACION DE LABORATORIO (LIS) - REPORTE OFICIAL DE RESULTADOS", 14, 34);
      
      // Patient Demographics card
      doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
      doc.rect(14, 44, 182, 36, 'F');
      
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(10);
      doc.text("DATOS DEL PACIENTE", 18, 50);
      doc.text("DATOS DEL ANALISIS", 110, 50);
      
      doc.setFont('Helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(`Nombre: ${selectedOrder.patientName}`, 18, 56);
      doc.text(`DUI: ${selectedPatientRecord.dui || 'N/A'}`, 18, 62);
      doc.text(`Edad: ${selectedOrder.patientAge} anos  |  Sexo: ${selectedOrder.patientGender === 'M' ? 'Masculino' : 'Femenino'}`, 18, 68);
      doc.text(`Email/Tel: ${selectedPatientRecord.email || 'N/A'} • ${selectedPatientRecord.phone}`, 18, 74);
      
      doc.text(`No. Orden: ${selectedOrder.orderNumber}`, 110, 56);
      doc.text(`Medico: ${selectedOrder.doctorName}`, 110, 62);
      doc.text(`Fecha Emision: ${new Date(selectedOrder.createdAt).toLocaleDateString('es-SV')}`, 110, 68);
      doc.text(`Estado Pago: ${selectedOrder.paymentStatus}`, 110, 74);
      
      // Core Results Header Table
      let y = 90;
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text("ESTUDIOS CLINICOS SOLICITADOS", 14, y - 4);
      
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(14, y, 182, 8, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(9);
      doc.text("Analisis / Prueba", 18, y + 5);
      doc.text("Resultado", 85, y + 5);
      doc.text("Unidad", 125, y + 5);
      doc.text("Valores de Referencia", 145, y + 5);
      
      y += 8;
      
      // Draw rows
      selectedOrder.examCodes.forEach((code, idx) => {
        const exam = exams.find(e => e.code === code);
        const res = results.find(r => r.orderNumber === selectedOrder.orderNumber && r.examCode === code);
        const ref = findReferenceRange(code, selectedOrder.patientAge, selectedOrder.patientGender);

        const drawStandardRow = (sc_code: string, sc_exam: any, sc_res: any, sc_ref: any) => {
          if (y > 270) {
            doc.addPage();
            y = 20;
          }

          if (idx % 2 === 0) {
            doc.setFillColor(248, 250, 252);
            doc.rect(14, y, 182, 12, 'F');
          }
          
          doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(9);
          doc.text(sc_exam ? sc_exam.name : 'Examen', 18, y + 7);
          
          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(8);
          doc.text(`Metodo: ${sc_exam?.method || 'N/A'}`, 18, y + 10);
          
          // Value
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(9);
          doc.text(sc_res ? sc_res.value : 'Pendiente', 85, y + 7);
          
          // Unit
          doc.setFont('Helvetica', 'normal');
          doc.text(sc_exam?.unit || 'N/A', 125, y + 7);
          
          // Range
          let rangeStr = '';
          if (sc_ref) {
            if (sc_ref.valMin !== null && sc_ref.valMax !== null) {
              rangeStr = `${sc_ref.valMin} - ${sc_ref.valMax}`;
            } else if (sc_ref.textReference) {
              rangeStr = sc_ref.textReference;
            } else {
              rangeStr = 'Establecido';
            }
          } else {
            rangeStr = 'N/A';
          }
          
          doc.text(rangeStr, 145, y + 7);
          
          y += 12;
        };

        if (res && res.value && res.value.startsWith('{')) {
          try {
            const data = JSON.parse(res.value);
            
            // Draw a section header for the custom test
            if (y > 260) {
              doc.addPage();
              y = 20;
            }
            doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
            doc.rect(14, y, 182, 8, 'F');
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(9);
            doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
            doc.text(`${exam ? exam.name : 'Examen'} - Reporte Detallado`, 18, y + 5.5);
            y += 8;

            let subRows: { name: string; val: string; unit: string; ref: string }[] = [];
            if (code === 'HEM01') {
              subRows = [
                { name: 'Globulos Rojos', val: data.globulosRojos, unit: 'M/uL', ref: '4.5 - 5.9 (H) | 4.0 - 5.2 (M)' },
                { name: 'Hemoglobina', val: data.hemoglobina, unit: 'g/dL', ref: '13.8 - 17.2 (H) | 12.1 - 15.1 (M)' },
                { name: 'Hematocrito', val: data.hematocrito, unit: '%', ref: '41 - 50 (H) | 36 - 46 (M)' },
                { name: 'VCM', val: data.vcm, unit: 'fL', ref: '80 - 100' },
                { name: 'HCM', val: data.hcm, unit: 'pg', ref: '27 - 33' },
                { name: 'CHCM', val: data.chcm, unit: 'g/dL', ref: '32 - 36' },
                { name: 'RDW', val: data.rdw, unit: '%', ref: '11.5 - 14.5' },
                { name: 'Plaquetas', val: data.plaquetas, unit: '/uL', ref: '150,000 - 450,000' },
                { name: 'VPM', val: data.vpm, unit: 'fL', ref: '7.4 - 10.4' },
                { name: 'Leucocitos', val: data.globulosBlancos, unit: '/uL', ref: '4,500 - 11,000' },
                { name: 'Neutrofilos', val: data.neutrofilos, unit: '%', ref: '40 - 70' },
                { name: 'Linfocitos', val: data.linfocitos, unit: '%', ref: '20 - 45' },
                { name: 'Monocitos', val: data.monocitos, unit: '%', ref: '2 - 10' },
                { name: 'Eosinofilos', val: data.eosinofilos, unit: '%', ref: '1 - 6' },
                { name: 'Basofilos', val: data.basofilos, unit: '%', ref: '0 - 2' }
              ];
            } else if (code === 'EGO01') {
              subRows = [
                { name: 'Color', val: data.color, unit: '', ref: 'Amarillo' },
                { name: 'Aspecto', val: data.aspecto, unit: '', ref: 'Limpio' },
                { name: 'Densidad', val: data.densidad, unit: '', ref: '1.005 - 1.030' },
                { name: 'pH', val: data.ph, unit: '', ref: '5.0 - 7.5' },
                { name: 'Proteinas', val: data.proteinas, unit: '', ref: 'Negativo' },
                { name: 'Glucosa', val: data.glucosa, unit: '', ref: 'Negativo' },
                { name: 'Cetonas', val: data.cetonas, unit: '', ref: 'Negativo' },
                { name: 'Bilirrubina', val: data.bilirrubina, unit: '', ref: 'Negativo' },
                { name: 'Urobilinogeno', val: data.urobilinogeno, unit: '', ref: 'Normal' },
                { name: 'Sangre Oculta', val: data.sangreOculta, unit: '', ref: 'Negativo' },
                { name: 'Nitritos', val: data.nitritos, unit: '', ref: 'Negativo' },
                { name: 'Est. Leucocitaria', val: data.leucocitosQuimico, unit: '', ref: 'Negativo' },
                { name: 'Leucocitos (Campo)', val: data.leucocitosSedimento, unit: 'x campo', ref: '0 - 5' },
                { name: 'Hematies (Campo)', val: data.hematies, unit: 'x campo', ref: '0 - 2' },
                { name: 'Cel. Epiteliales', val: data.celulasEpiteliales, unit: '', ref: 'Escasas' },
                { name: 'Bacterias', val: data.bacterias, unit: '', ref: 'Escasas' },
                { name: 'Cristales', val: data.cristales, unit: '', ref: 'No se observan' },
                { name: 'Cilindros', val: data.cilindros, unit: '', ref: 'No se observan' },
                { name: 'Filamento Mucoide', val: data.filamentoMucoide, unit: '', ref: 'Escaso' },
                { name: 'Levaduras', val: data.levaduras, unit: '', ref: 'No se observan' }
              ];
            } else if (code === 'EGC01' || code === 'EGH01') {
              subRows = [
                { name: 'Color', val: data.color, unit: '', ref: 'Cafe' },
                { name: 'Consistencia', val: data.consistencia, unit: '', ref: 'Pastosa' },
                { name: 'Moco Fecal', val: data.moco, unit: '', ref: 'Negativo' },
                { name: 'Sangre Macro.', val: data.sangreMacroscopico, unit: '', ref: 'Negativo' },
                { name: 'Leucocitos (Campo)', val: data.leucocitos, unit: 'x campo', ref: '0 - 2' },
                { name: 'Hematies (Campo)', val: data.hematies, unit: 'x campo', ref: '0 - 1' },
                { name: 'Levaduras', val: data.levaduras, unit: '', ref: 'No se observan' },
                { name: 'Fibras Alimenticias', val: data.fibrasAlimenticias, unit: '', ref: 'Escasas' },
                { name: 'Almidones', val: data.almidones, unit: '', ref: 'No se observan' },
                { name: 'Grasas', val: data.grasas, unit: '', ref: 'No se observan' },
                { name: 'Quistes Ameba', val: data.quistesAmeba, unit: '', ref: 'No se observan' },
                { name: 'Trofozoitos', val: data.trofozoitos, unit: '', ref: 'No se observan' },
                { name: 'Huevos Helmintos', val: data.huevosHelmintos, unit: '', ref: 'No se observan' },
                { name: 'Larvas', val: data.larvas, unit: '', ref: 'No se observan' }
              ];
            }

            subRows.forEach((sr, sidx) => {
              if (y > 275) {
                doc.addPage();
                y = 20;
              }

              if (sidx % 2 === 0) {
                doc.setFillColor(250, 250, 250);
                doc.rect(14, y, 182, 7, 'F');
              }
              
              doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
              doc.setFont('Helvetica', 'normal');
              doc.setFontSize(8);
              doc.text(`  * ${sr.name}`, 18, y + 4.5);
              
              doc.setFont('Helvetica', 'bold');
              doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
              doc.text(String(sr.val || 'N/A'), 85, y + 4.5);
              
              doc.setFont('Helvetica', 'normal');
              doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
              doc.text(sr.unit || '-', 125, y + 4.5);
              doc.text(sr.ref, 145, y + 4.5);
              
              y += 7;
            });
            
            y += 3;

          } catch (e) {
            drawStandardRow(code, exam, res, ref);
          }
        } else {
          drawStandardRow(code, exam, res, ref);
        }
      });
      
      // Observations section
      y += 10;
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(9);
      doc.text("OBSERVACIONES GENERALES", 14, y);
      doc.setFont('Helvetica', 'normal');
      doc.setFontSize(8);
      
      let combinedObs = selectedOrder.examCodes
        .map(code => {
          const res = results.find(r => r.orderNumber === selectedOrder.orderNumber && r.examCode === code);
          return res?.observations ? `${code}: ${res.observations}` : '';
        })
        .filter(Boolean)
        .join(' | ');
        
      doc.text(combinedObs || "Muestras procesadas segun protocolos de control de calidad interno. Sin comentarios adicionales.", 14, y + 5);
      
      // Signature representation and stamp
      y += 25;
      doc.setDrawColor(200, 200, 200);
      doc.line(14, y, 90, y);
      
      const validator = results.find(r => r.orderNumber === selectedOrder.orderNumber)?.verifiedBy || "Dr. Roberto Solis - Reg. JVPM 8492";
      
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(9);
      doc.text("Firma Digital del Profesional", 14, y + 5);
      doc.setFont('Helvetica', 'italic');
      doc.setFontSize(8);
      doc.text(validator, 14, y + 9);
      doc.text("Registro Medico LIS Sello Oficial", 14, y + 13);

      // Sello Redondo Oficial de Laboratorio en PDF (azul tinta)
      doc.setDrawColor(79, 70, 229); // indigo-600 (azul sello)
      doc.setLineWidth(0.5);
      doc.circle(115, y + 6, 14, 'S'); // círculo de radio 14
      
      doc.setTextColor(79, 70, 229);
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(5);
      doc.text("SELLO OFICIAL", 115, y - 2, { align: 'center' });
      
      const sLines = letterhead.stampLines;
      if (sLines && sLines.length > 0) {
        doc.text(sLines[0] || "MONTEHOREB", 115, y + 2, { align: 'center' });
        doc.text(sLines[1] || "CSSP 1716", 115, y + 5, { align: 'center' });
        doc.text(sLines[2] || "PROPIETARIA", 115, y + 8, { align: 'center' });
        doc.text(sLines[3] || "CHALCHUAPA", 115, y + 11, { align: 'center' });
      }
      
      // Reset color for other elements
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      
      // QR stamp simulation
      doc.rect(145, y - 10, 35, 35);
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(6);
      doc.text("Escanear para", 147, y + 5);
      doc.text("Verificar Autenticidad", 147, y + 8);
      doc.text("LIS-WEB-PORTAL", 147, y + 11);
      doc.setFontSize(5);
      doc.text(`ORD-VERIF-${orderNum}`, 147, y + 16);
      
      doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(173, y - 8, 5, 5, 'F');
      doc.rect(173, y + 12, 5, 5, 'F');
      doc.rect(147, y - 8, 5, 5, 'F');
      
      doc.save(`reporte_clinico_lis_${orderNum}.pdf`);
      onAddAuditLog('Descargar PDF', `Descargó reporte PDF oficial para la orden ${orderNum} del paciente ${selectedOrder.patientName}.`);
    } catch (e) {
      console.error(e);
      alert('Error generando el archivo PDF.');
    }
  };

  return (
    <div className="space-y-4">
      {/* Selection screen */}
      {!selectedOrder ? (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
            <h1 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Reportería y Certificados PDF</h1>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Consulte expedientes completados o validados para ver preliminares oficiales, imprimir o emitir reportes firmados con sello digital QR.
            </p>
          </div>

          <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs max-w-2xl space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Buscar Orden Validada</h3>
            <div className="relative">
              <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
              <input
                id="report_search"
                type="text"
                placeholder="Buscar por código de orden o nombre de paciente..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-800 placeholder-slate-400"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto pr-1">
              {reportReadyOrders.map(order => {
                const isValidated = order.status === 'Validado';
                return (
                  <button
                    id={`report_order_` + order.orderNumber}
                    key={order.orderNumber}
                    onClick={() => onSelectOrder(order)}
                    className="w-full text-left py-2 px-2.5 hover:bg-slate-50/70 flex justify-between items-center transition-colors cursor-pointer rounded-md"
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs font-bold text-blue-600">{order.orderNumber}</span>
                        <span className={`inline-flex px-1.5 py-0.2 text-[8px] font-black rounded ${
                          isValidated ? 'bg-emerald-50 text-emerald-850 border border-emerald-200' : 'bg-blue-50 text-blue-850 border border-blue-200'
                        }`}>
                          {isValidated ? 'FIRMADO' : 'PENDIENTE FIRMA'}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-850 mt-1">{order.patientName}</h4>
                      <p className="text-[10px] text-slate-450 mt-0.5">Médico: {order.doctorName} • {order.examCodes.length} análisis</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {isValidated ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Clock className="w-4 h-4 text-blue-500 animate-pulse" />
                      )}
                    </div>
                  </button>
                );
              })}
              {reportReadyOrders.length === 0 && (
                <div className="text-center py-10 text-xs text-slate-400 font-semibold">
                  No se encontraron órdenes validadas o listas para firmar en este filtro.
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Report detail & printable template preview */
        <div className="space-y-4">
          {/* Top buttons bar */}
          <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg border border-slate-200">
            <button
              id="report_back_btn"
              onClick={() => onSelectOrder(null)}
              className="px-2.5 py-1.5 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-md border border-slate-250 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Volver a la Lista
            </button>

            <div className="flex gap-2">
              <button
                id="report_pdf_download_btn"
                onClick={handleDownloadPdf}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors flex items-center gap-1.5 cursor-pointer shadow-3xs"
              >
                <Download className="w-3.5 h-3.5" /> Certificado PDF
              </button>
              <button
                id="report_print_btn"
                onClick={() => window.print()}
                className="px-3 py-1.5 bg-slate-905 hover:bg-slate-800 text-slate-100 bg-slate-900 font-bold text-xs rounded-md transition-colors flex items-center gap-1.5 cursor-pointer border border-transparent shadow-3xs"
              >
                <Printer className="w-3.5 h-3.5" /> Imprimir Reporte
              </button>
            </div>
          </div>

          {/* Letterhead Preview Document */}
          <div className="bg-white p-6 md:p-8 rounded-lg border border-slate-250 shadow-xs max-w-3xl mx-auto space-y-6 print:border-none print:shadow-none print:p-0" id="print-clinical-report">
            {/* Report Letterhead Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-300 pb-4 gap-3 text-center md:text-left">
              <div className="flex-1">
                <h1 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-1.5 uppercase justify-center md:justify-start">
                  <FileText className="w-5 h-5 text-blue-600" />
                  {letterhead.labName}
                </h1>
                <p className="text-[10px] text-slate-500 font-bold mt-0.5">
                  {letterhead.slogan} • {letterhead.cssp}
                </p>
                <p className="text-[9px] text-slate-400 font-medium">
                  {letterhead.address}
                </p>
                <p className="text-[9px] text-slate-550 font-medium">
                  Tels: {letterhead.phoneLandline} / {letterhead.phoneCell} • Directora: {letterhead.ownerName} ({letterhead.jvplc})
                </p>
                <p className="text-[9px] text-slate-400 font-mono font-bold tracking-wider mt-1.5">SISTEMA LIS SECURE • REPORTE DE RESULTADOS OFICIAL</p>
              </div>
              <div className="text-right flex flex-col items-center md:items-end gap-0.5 shrink-0 self-center md:self-auto">
                <span className="font-mono text-sm font-black text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded border border-blue-150">
                  {selectedOrder.orderNumber}
                </span>
                <span className="text-[9px] text-slate-400 font-bold">
                  Emisión: {new Date(selectedOrder.createdAt).toLocaleDateString('es-SV')}
                </span>
              </div>
            </div>

            {/* Demographics segment */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50/75 p-4 rounded-lg border border-slate-200 text-xs">
              <div className="space-y-1.5">
                <h3 className="text-[9px] font-black uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-0.5">Paciente</h3>
                <div className="space-y-0.5 text-slate-750 font-semibold">
                  <p className="text-slate-500">Nombre: <strong className="text-slate-900 block font-bold">{selectedOrder.patientName}</strong></p>
                  <p className="text-slate-500">DUI: <strong className="text-slate-800 font-mono">{selectedPatientRecord?.dui}</strong></p>
                  <p className="text-slate-500">Edad/Sexo: <strong className="text-slate-800">{selectedOrder.patientAge} años • {selectedOrder.patientGender === 'M' ? 'Masculino' : 'Femenino'}</strong></p>
                  <p className="text-slate-500">Contacto: <strong className="text-slate-800">{selectedPatientRecord?.phone} • {selectedPatientRecord?.email || 'N/A'}</strong></p>
                </div>
              </div>

              <div className="space-y-1.5">
                <h3 className="text-[9px] font-black uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-0.5">Orden Clínico</h3>
                <div className="space-y-0.5 text-slate-750 font-semibold">
                  <p className="text-slate-500">Médico Tratante: <strong className="text-slate-800 block font-bold">Dr(a). {selectedOrder.doctorName}</strong></p>
                  <p className="text-slate-500">Expediente LIS: <strong className="text-slate-800 font-mono">{selectedOrder.orderNumber}</strong></p>
                  <p className="text-slate-500">Estado Pago: <span className="inline-flex px-1.5 py-0.2 text-[9px] font-black rounded bg-slate-200 text-slate-750">{selectedOrder.paymentStatus}</span></p>
                </div>
              </div>
            </div>

            {/* Clinical results table */}
            <div className="space-y-2">
              <h3 className="text-[10px] font-bold text-slate-450 uppercase tracking-wider">Reporte Analítico Detallado</h3>
              <div className="border border-slate-200 rounded-lg overflow-hidden shadow-3xs">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-900 text-white font-bold uppercase tracking-wider text-[9px]">
                      <th className="py-2 px-3">Análisis / Prueba</th>
                      <th className="py-2 px-3">Resultado Reportado</th>
                      <th className="py-2 px-3 text-center">Unidad</th>
                      <th className="py-2 px-3">Rangos de Referencia Clínicos</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-150 font-medium">
                    {selectedOrder.examCodes.map(code => {
                      const exam = exams.find(e => e.code === code);
                      const res = results.find(r => r.orderNumber === selectedOrder.orderNumber && r.examCode === code);
                      const ref = findReferenceRange(code, selectedOrder.patientAge, selectedOrder.patientGender);

                      const isStructured = res && res.value && res.value.startsWith('{');

                      return (
                        <tr key={code} className="hover:bg-slate-50/50">
                          <td className="py-2 px-3 space-y-0.5">
                            <div className="font-bold text-slate-900 text-xs">{exam?.name}</div>
                            <div className="text-[9px] text-slate-400">Método Analítico: {exam?.method} • Código: {code}</div>
                          </td>
                          <td className="py-2 px-3 font-extrabold text-xs text-slate-900 font-mono" colSpan={isStructured ? 3 : 1}>
                            {res ? (
                              isStructured ? (
                                renderStructuredPreview(code, res.value)
                              ) : (
                                res.value
                              )
                            ) : (
                              <span className="text-slate-400 font-normal italic">Pendiente de ingreso</span>
                            )}
                          </td>
                          {!isStructured && (
                            <>
                              <td className="py-2 px-3 text-center font-bold text-slate-600">
                                {exam?.unit || '-'}
                              </td>
                              <td className="py-2 px-3 text-slate-700 text-xs leading-normal">
                                {ref ? (
                                  ref.valMin !== null && ref.valMax !== null ? (
                                    <p>Rango Normal: <strong className="font-mono text-slate-900">{ref.valMin} - {ref.valMax}</strong> {ref.unit}</p>
                                  ) : ref.textReference ? (
                                    <p className="font-bold text-slate-800">{ref.textReference}</p>
                                  ) : (
                                    <p className="text-slate-400 italic">Cualitativo / Subjetivo</p>
                                  )
                                ) : (
                                  <p className="text-slate-400 italic">No establecido</p>
                                )}
                                {ref?.observations && <p className="text-[9px] text-slate-400 mt-0.5 italic">Obs: {ref.observations}</p>}
                              </td>
                            </>
                          )}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Observations / Comments */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600 space-y-1 font-semibold">
              <h4 className="font-bold text-slate-800 uppercase text-[9px] tracking-wider text-slate-400">Anotaciones del Tecnólogo Clínico</h4>
              <p className="text-[11px] leading-relaxed">
                {selectedOrder.examCodes.map(code => {
                  const res = results.find(r => r.orderNumber === selectedOrder.orderNumber && r.examCode === code);
                  return res?.observations ? `• ${code}: ${res.observations}` : null;
                }).filter(Boolean).join(' ') || "Los controles y calibradores de cada ensayo clínico se procesaron de forma satisfactoria según especificaciones técnicas internacionales de laboratorio."}
              </p>
            </div>

             {/* Signatures stamp and QR Code authenticity container */}
            <div className="flex flex-col sm:flex-row justify-between items-center pt-5 border-t border-slate-200 gap-4">
              {/* Left stamp and signature */}
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
                <div className="space-y-0.5 shrink-0">
                  <div className="font-bold text-slate-900 text-xs font-mono border-b border-dashed border-slate-300 pb-1.5 w-60 italic">
                    {results.find(r => r.orderNumber === selectedOrder.orderNumber)?.verifiedBy || "Pendiente de validación"}
                  </div>
                  <h4 className="text-[9px] font-black uppercase tracking-wider text-slate-400">Responsable de Validación</h4>
                  <p className="text-[8px] text-slate-500 font-bold">Firma electrónica certificada LIS</p>
                </div>

                {/* Sello de Laboratorio Redondo Realista */}
                <div className="border-2 border-indigo-600/45 p-1 rounded-full w-24 h-24 flex flex-col justify-center items-center text-[7px] text-indigo-700/90 font-black tracking-tighter uppercase select-none rotate-[-4deg] bg-indigo-55/5 shrink-0 border-dashed">
                  <span className="text-[6px] text-indigo-600/60 border-b border-indigo-400/20 pb-0.5 mb-0.5 font-bold">SELLO OFICIAL</span>
                  {letterhead.stampLines.slice(0, 4).map((line, li) => (
                    <span key={li} className="truncate max-w-[85px] text-center font-bold text-[6px] tracking-tight">{line}</span>
                  ))}
                </div>
              </div>

              {/* Right QR authenticity stamp */}
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center gap-3 max-w-sm">
                <div className="w-12 h-12 bg-white p-1 border border-slate-200 rounded flex flex-wrap gap-0.5 justify-center items-center shrink-0">
                  <div className="grid grid-cols-5 gap-0.5 w-full h-full">
                    {Array.from({ length: 25 }).map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-full h-full ${
                          (i % 3 === 0 || i % 7 === 0 || i === 0 || i === 4 || i === 20 || i === 24) 
                            ? 'bg-slate-950' 
                            : 'bg-transparent'
                        }`} 
                      />
                    ))}
                  </div>
                </div>
                <div className="text-[9px] text-slate-500 space-y-0.5 font-medium leading-tight">
                  <span className="font-black text-blue-700 uppercase block tracking-wider text-[8px]">QR de Verificación Seguro</span>
                  <p className="font-bold text-slate-800">Sello de Autenticidad Oficial LIS</p>
                  <p className="font-mono text-slate-400">ORD-{selectedOrder.orderNumber}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
