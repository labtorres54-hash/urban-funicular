/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  FileSpreadsheet, 
  CheckCircle, 
  Edit3, 
  History, 
  Award, 
  Save, 
  X, 
  AlertTriangle, 
  Search, 
  User, 
  ShieldCheck 
} from 'lucide-react';
import { Order, Exam, ExamResult, ReferenceRange, User as LisUser } from '../types/lis';

interface ResultsEntryProps {
  orders: Order[];
  exams: Exam[];
  results: ExamResult[];
  referenceRanges: ReferenceRange[];
  currentUser: LisUser;
  onUpdateResults: (results: ExamResult[]) => void;
  onUpdateOrderStatus: (orderNumber: string, status: 'Pendiente' | 'Completado' | 'Validado') => void;
  onAddAuditLog: (action: string, details: string) => void;
  onSelectOrderForReport: (order: Order) => void;
  onNavigate: (view: string) => void;
}

export default function ResultsEntry({ 
  orders, 
  exams, 
  results, 
  referenceRanges, 
  currentUser,
  onUpdateResults,
  onUpdateOrderStatus,
  onAddAuditLog,
  onSelectOrderForReport,
  onNavigate
}: ResultsEntryProps) {
  const [selectedOrderNumber, setSelectedOrderNumber] = useState<string | null>(null);
  const [orderFilter, setOrderFilter] = useState<'Todos' | 'Pendiente' | 'Completado' | 'Validado'>('Todos');
  const [searchQuery, setSearchQuery] = useState('');

  // Values being actively edited for the selected order
  const [activeWorksheet, setActiveWorksheet] = useState<{ [examCode: string]: { value: string; observations: string } }>({});
  const [selectedSignature, setSelectedSignature] = useState<string>(currentUser.signature || '');
  const [showHistoryForExamCode, setShowHistoryForExamCode] = useState<string | null>(null);
  const [reasonForChange, setReasonForChange] = useState('');

  // Find selected order details
  const selectedOrder = useMemo(() => {
    return orders.find(o => o.orderNumber === selectedOrderNumber) || null;
  }, [selectedOrderNumber, orders]);

  // Load order results into editable worksheet
  const handleSelectOrder = (order: Order) => {
    setSelectedOrderNumber(order.orderNumber);
    
    // Pre-populate worksheet with existing results if any
    const sheet: typeof activeWorksheet = {};
    order.examCodes.forEach(code => {
      const existingRes = results.find(r => r.orderNumber === order.orderNumber && r.examCode === code);
      sheet[code] = {
        value: existingRes ? existingRes.value : '',
        observations: existingRes?.observations || ''
      };
    });
    setActiveWorksheet(sheet);
    setSelectedSignature(currentUser.signature || '');
  };

  // Filters
  const getOrderTimes = (order: Order) => {
    const entryDate = new Date(order.createdAt);
    const entryStr = entryDate.toLocaleString('es-SV', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit', 
      minute: '2-digit', 
      hour12: true 
    });

    // Find custom delivery times of assigned exams
    let maxHours = 4; // default to 4 hours standard clinic turnaround
    order.examCodes.forEach(code => {
      const exam = exams.find(e => e.code === code);
      if (exam && exam.deliveryTime) {
        const matches = exam.deliveryTime.match(/(\d+)\s*(hora|día|dia)/i);
        if (matches) {
          const value = parseInt(matches[1]);
          const unit = matches[2].toLowerCase();
          if (unit.startsWith('dia')) {
            maxHours = Math.max(maxHours, value * 24);
          } else {
            maxHours = Math.max(maxHours, value);
          }
        }
      }
    });

    const deliveryDate = new Date(entryDate.getTime() + maxHours * 60 * 60 * 1000);
    const deliveryStr = deliveryDate.toLocaleString('es-SV', {
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit', 
      minute: '2-digit', 
      hour12: true 
    });

    return {
      entry: entryStr,
      delivery: deliveryStr,
      maxHours
    };
  };

  const filteredOrders = useMemo(() => {
    return orders.filter(o => {
      const matchesSearch = o.patientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            o.orderNumber.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = orderFilter === 'Todos' || o.status === orderFilter;
      return matchesSearch && matchesStatus;
    });
  }, [orders, orderFilter, searchQuery]);

  // Find reference range for a specific patient (age/sex) and exam
  const findReferenceRange = (examCode: string, age: number, sex: 'M' | 'F' | 'Otro'): ReferenceRange | null => {
    const normalizedSex = (sex === 'M' || sex === 'F') ? sex : 'Todos';
    const candidates = referenceRanges.filter(r => r.examCode === examCode);
    let ageMatch = candidates.filter(r => age >= r.ageMin && age <= r.ageMax);
    let sexMatch = ageMatch.filter(r => r.sex === normalizedSex || r.sex === 'Todos');
    
    if (sexMatch.length > 0) return sexMatch[0];
    if (ageMatch.length > 0) return ageMatch[0];
    if (candidates.length > 0) return candidates[0];
    
    return null;
  };

  // Handle Result Value change
  const handleValueChange = (code: string, val: string) => {
    setActiveWorksheet(prev => ({
      ...prev,
      [code]: { ...prev[code], value: val }
    }));
  };

  // Handle Observations change
  const handleObservationsChange = (code: string, obs: string) => {
    setActiveWorksheet(prev => ({
      ...prev,
      [code]: { ...prev[code], observations: obs }
    }));
  };

  // Helper to parse or generate empty structured data
  const getInitialStructuredData = (code: string, currentVal?: string) => {
    try {
      if (currentVal && currentVal.startsWith('{')) {
        return JSON.parse(currentVal);
      }
    } catch (e) {}

    if (code === 'HEM01') {
      return {
        globulosRojos: '', hemoglobina: '', hematocrito: '', vcm: '', hcm: '', chcm: '', rdw: '',
        plaquetas: '', vpm: '', globulosBlancos: '', neutrofilos: '', linfocitos: '', monocitos: '',
        eosinofilos: '', basofilos: ''
      };
    }
    if (code === 'EGO01') {
      return {
        color: '', aspecto: '', densidad: '', ph: '', proteinas: '', glucosa: '', cetonas: '',
        bilirrubina: '', urobilinogeno: '', sangreOculta: '', nitritos: '', leucocitosQuimico: '',
        leucocitosSedimento: '', hematies: '', celulasEpiteliales: '', cristales: '', cilindros: '',
        bacterias: '', filamentoMucoide: '', levaduras: ''
      };
    }
    if (code === 'EGC01' || code === 'EGH01') {
      return {
        color: '', consistencia: '', moco: '', sangreMacroscopico: '', leucocitos: '', hematies: '',
        levaduras: '', quistesAmeba: '', trofozoitos: '', huevosHelmintos: '', larvas: '',
        fibrasAlimenticias: '', almidones: '', grasas: ''
      };
    }
    return {};
  };

  // Pre-fill Normal Template
  const handlePrefillTemplate = (code: string) => {
    let normalObj = {};
    if (code === 'HEM01') {
      normalObj = {
        globulosRojos: '4.8', hemoglobina: '14.2', hematocrito: '42', vcm: '88', hcm: '29.5', chcm: '33.5', rdw: '13.0',
        plaquetas: '250,000', vpm: '8.5', globulosBlancos: '7,200', neutrofilos: '60', linfocitos: '30', monocitos: '6',
        eosinofilos: '3', basofilos: '1'
      };
    } else if (code === 'EGO01') {
      normalObj = {
        color: 'Amarillo', aspecto: 'Limpio', densidad: '1.020', ph: '6.0', proteinas: 'Negativo', glucosa: 'Negativo', cetonas: 'Negativo',
        bilirrubina: 'Negativo', urobilinogeno: 'Normal', sangreOculta: 'Negativo', nitritos: 'Negativo', leucocitosQuimico: 'Negativo',
        leucocitosSedimento: '0-5', hematies: '0-2', celulasEpiteliales: 'Escasas', cristales: 'No se observan', cilindros: 'No se observan',
        bacterias: 'Escasas', filamentoMucoide: 'Escaso', levaduras: 'No se observan'
      };
    } else if (code === 'EGC01' || code === 'EGH01') {
      normalObj = {
        color: 'Café', consistencia: 'Pastosa', moco: 'Negativo', sangreMacroscopico: 'Negativo', leucocitos: '0-2', hematies: '0-1',
        levaduras: 'No se observan', quistesAmeba: 'No se observan', trofozoitos: 'No se observan', huevosHelmintos: 'No se observan', larvas: 'No se observan',
        fibrasAlimenticias: 'Escasas', almidones: 'No se observan', grasas: 'No se observan'
      };
    }
    handleValueChange(code, JSON.stringify(normalObj));
  };

  const handleSubFieldChange = (code: string, field: string, value: string) => {
    let currentObj = {};
    try {
      const currentVal = activeWorksheet[code]?.value || '';
      if (currentVal.startsWith('{')) {
        currentObj = JSON.parse(currentVal);
      } else {
        currentObj = getInitialStructuredData(code);
      }
    } catch (e) {
      currentObj = getInitialStructuredData(code);
    }
    
    const updated = { ...currentObj, [field]: value };
    handleValueChange(code, JSON.stringify(updated));
  };

  const renderCustomStructuredForm = (code: string, resultValue: string, isDisabled: boolean) => {
    const data = getInitialStructuredData(code, resultValue);

    if (code === 'HEM01') {
      return (
        <div className="space-y-3.5 border border-slate-200 bg-slate-50/50 p-3 rounded-lg mt-1 text-xs w-full">
          <div className="flex justify-between items-center border-b border-slate-200 pb-1.5">
            <span className="font-extrabold text-slate-700 uppercase tracking-wider text-[10px]">Hemograma Completo (Detalle Clínico)</span>
            {!isDisabled && (
              <button
                type="button"
                onClick={() => handlePrefillTemplate('HEM01')}
                className="px-2 py-0.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded text-[10px] font-bold border border-blue-200 cursor-pointer"
              >
                Prellenar Valores Normales
              </button>
            )}
          </div>

          {/* Serie Roja */}
          <div className="space-y-1.5">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Serie Roja</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Glóbulo Rojo (M/µL)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.globulosRojos || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'globulosRojos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Hemoglobina (g/dL)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.hemoglobina || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'hemoglobina', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Hematocrito (%)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.hematocrito || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'hematocrito', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">VCM (fL)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.vcm || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'vcm', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">HCM (pg)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.hcm || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'hcm', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">CHCM (g/dL)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.chcm || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'chcm', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">RDW (%)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.rdw || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'rdw', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Serie Plaquetaria */}
          <div className="space-y-1.5 pt-1.5 border-t border-slate-200">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Serie Plaquetaria</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Plaquetas (/µL)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.plaquetas || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'plaquetas', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">VPM (fL)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.vpm || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'vpm', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Serie Blanca */}
          <div className="space-y-1.5 pt-1.5 border-t border-slate-200">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Serie Blanca y Diferencial</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Leucocitos (/µL)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.globulosBlancos || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'globulosBlancos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Neutrófilos (%)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.neutrofilos || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'neutrofilos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Linfocitos (%)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.linfocitos || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'linfocitos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Monocitos (%)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.monocitos || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'monocitos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Eosinófilos (%)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.eosinofilos || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'eosinofilos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Basófilos (%)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.basofilos || ''}
                  onChange={(e) => handleSubFieldChange('HEM01', 'basofilos', e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (code === 'EGO01') {
      return (
        <div className="space-y-3.5 border border-slate-200 bg-slate-50/50 p-3 rounded-lg mt-1 text-xs w-full">
          <div className="flex justify-between items-center border-b border-slate-200 pb-1.5">
            <span className="font-extrabold text-slate-700 uppercase tracking-wider text-[10px]">Examen General de Orina (Detalle Clínico)</span>
            {!isDisabled && (
              <button
                type="button"
                onClick={() => handlePrefillTemplate('EGO01')}
                className="px-2 py-0.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded text-[10px] font-bold border border-blue-200 cursor-pointer"
              >
                Prellenar Plantilla Normal
              </button>
            )}
          </div>

          {/* Físico */}
          <div className="space-y-1.5">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Examen Físico</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Color</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.color || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'color', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Aspecto</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.aspecto || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'aspecto', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Densidad</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.densidad || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'densidad', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">pH</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 text-center font-mono font-bold"
                  value={data.ph || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'ph', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Químico */}
          <div className="space-y-1.5 pt-1.5 border-t border-slate-200">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Examen Químico</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Proteínas</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.proteinas || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'proteinas', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Glucosa</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.glucosa || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'glucosa', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Cetonas</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.cetonas || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'cetonas', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Bilirrubina</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.bilirrubina || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'bilirrubina', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Urobilinógeno</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.urobilinogeno || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'urobilinogeno', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Sangre Oculta</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.sangreOculta || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'sangreOculta', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Nitritos</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.nitritos || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'nitritos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Est. Leucocitaria</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.leucocitosQuimico || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'leucocitosQuimico', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Sedimento */}
          <div className="space-y-1.5 pt-1.5 border-t border-slate-200">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Sedimento Urinario (Microscópico)</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Leucocitos (x campo)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.leucocitosSedimento || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'leucocitosSedimento', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Hematíes (x campo)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.hematies || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'hematies', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Cel. Epiteliales</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.celulasEpiteliales || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'celulasEpiteliales', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Bacterias</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.bacterias || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'bacterias', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Cristales</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.cristales || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'cristales', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Cilindros</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.cilindros || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'cilindros', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Filamento Mucoide</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.filamentoMucoide || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'filamentoMucoide', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Levaduras</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.levaduras || ''}
                  onChange={(e) => handleSubFieldChange('EGO01', 'levaduras', e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (code === 'EGC01' || code === 'EGH01') {
      return (
        <div className="space-y-3.5 border border-slate-200 bg-slate-50/50 p-3 rounded-lg mt-1 text-xs w-full">
          <div className="flex justify-between items-center border-b border-slate-200 pb-1.5">
            <span className="font-extrabold text-slate-700 uppercase tracking-wider text-[10px]">Examen General de Heces (Detalle Clínico)</span>
            {!isDisabled && (
              <button
                type="button"
                onClick={() => handlePrefillTemplate(code)}
                className="px-2 py-0.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded text-[10px] font-bold border border-blue-200 cursor-pointer"
              >
                Prellenar Plantilla Normal
              </button>
            )}
          </div>

          {/* Físico */}
          <div className="space-y-1.5">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Análisis Macroscópico</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Color</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.color || ''}
                  onChange={(e) => handleSubFieldChange(code, 'color', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Consistencia</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.consistencia || ''}
                  onChange={(e) => handleSubFieldChange(code, 'consistencia', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Moco Fecal</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.moco || ''}
                  onChange={(e) => handleSubFieldChange(code, 'moco', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Sangre Macroscópica</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.sangreMacroscopico || ''}
                  onChange={(e) => handleSubFieldChange(code, 'sangreMacroscopico', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Microscópico */}
          <div className="space-y-1.5 pt-1.5 border-t border-slate-200">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Análisis Microscópico</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Leucocitos (x campo)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.leucocitos || ''}
                  onChange={(e) => handleSubFieldChange(code, 'leucocitos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Hematíes (x campo)</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.hematies || ''}
                  onChange={(e) => handleSubFieldChange(code, 'hematies', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Levaduras</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.levaduras || ''}
                  onChange={(e) => handleSubFieldChange(code, 'levaduras', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Fibras Alimenticias</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.fibrasAlimenticias || ''}
                  onChange={(e) => handleSubFieldChange(code, 'fibrasAlimenticias', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Almidones</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.almidones || ''}
                  onChange={(e) => handleSubFieldChange(code, 'almidones', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Grasas</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold text-center"
                  value={data.grasas || ''}
                  onChange={(e) => handleSubFieldChange(code, 'grasas', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Parasitario */}
          <div className="space-y-1.5 pt-1.5 border-t border-slate-200">
            <span className="font-black text-blue-700 text-[9px] uppercase tracking-wider">Investigación de Parásitos</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Quistes Ameba</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.quistesAmeba || ''}
                  onChange={(e) => handleSubFieldChange(code, 'quistesAmeba', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Trofozoítos</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.trofozoitos || ''}
                  onChange={(e) => handleSubFieldChange(code, 'trofozoitos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Huevos Helmintos</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.huevosHelmintos || ''}
                  onChange={(e) => handleSubFieldChange(code, 'huevosHelmintos', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[9px] text-slate-500 font-bold mb-0.5">Larvas</label>
                <input
                  type="text"
                  disabled={isDisabled}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-md text-slate-800 font-bold"
                  value={data.larvas || ''}
                  onChange={(e) => handleSubFieldChange(code, 'larvas', e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  // Save entered values
  const handleSaveDraft = () => {
    if (!selectedOrder) return;

    let updatedResults = [...results];
    let logs: string[] = [];

    selectedOrder.examCodes.forEach(code => {
      const input = activeWorksheet[code];
      if (!input) return;

      const existingIdx = updatedResults.findIndex(r => r.orderNumber === selectedOrder.orderNumber && r.examCode === code);
      
      if (existingIdx > -1) {
        const original = updatedResults[existingIdx];
        if (original.value !== input.value && original.value !== '') {
          const histItem = {
            id: `HIST-${Date.now()}-${Math.floor(Math.random() * 100)}`,
            modifiedBy: currentUser.name,
            modifiedAt: new Date().toISOString(),
            oldValue: original.value,
            newValue: input.value,
            reason: reasonForChange || 'Actualización manual de rutina'
          };
          updatedResults[existingIdx] = {
            ...original,
            value: input.value,
            observations: input.observations,
            modifiedBy: currentUser.name,
            modifiedAt: new Date().toISOString(),
            history: [...original.history, histItem]
          };
          logs.push(`Modificó resultado de ${code}: de "${original.value}" a "${input.value}"`);
        } else {
          updatedResults[existingIdx] = {
            ...original,
            value: input.value,
            observations: input.observations
          };
        }
      } else {
        updatedResults.push({
          id: `RES-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          orderNumber: selectedOrder.orderNumber,
          examCode: code,
          value: input.value,
          status: 'Ingresado',
          observations: input.observations,
          history: []
        });
      }
    });

    onUpdateResults(updatedResults);
    
    const allFilled = selectedOrder.examCodes.every(code => activeWorksheet[code]?.value.trim() !== '');
    if (allFilled && selectedOrder.status === 'Pendiente') {
      onUpdateOrderStatus(selectedOrder.orderNumber, 'Completado');
      onAddAuditLog('Resultados - Completado', `Todos los resultados ingresados para la orden ${selectedOrder.orderNumber}. Estado promovido a Completado.`);
    }

    if (logs.length > 0) {
      onAddAuditLog('Resultados - Modificación', `Modificaciones en ${selectedOrder.orderNumber}: ${logs.join(', ')}. Razón: ${reasonForChange || 'Ninguna especificada'}`);
    } else {
      onAddAuditLog('Resultados - Guardar Borrador', `Guardó borrador de resultados para la orden ${selectedOrder.orderNumber}`);
    }

    setReasonForChange('');
    alert('Borrador de resultados guardado correctamente.');
  };

  // Validate results and digitally sign
  const handleValidateAndSign = () => {
    if (!selectedOrder) return;

    const allFilled = selectedOrder.examCodes.every(code => activeWorksheet[code]?.value.trim() !== '');
    if (!allFilled) {
      alert('No se puede validar ni firmar la orden porque aún existen pruebas sin resultados ingresados.');
      return;
    }

    if (!selectedSignature) {
      alert('Por favor proporcione o seleccione una firma digital para validar.');
      return;
    }

    let updatedResults = [...results];
    
    selectedOrder.examCodes.forEach(code => {
      const input = activeWorksheet[code];
      const existingIdx = updatedResults.findIndex(r => r.orderNumber === selectedOrder.orderNumber && r.examCode === code);
      
      const resItem: ExamResult = {
        id: existingIdx > -1 ? updatedResults[existingIdx].id : `RES-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        orderNumber: selectedOrder.orderNumber,
        examCode: code,
        value: input.value,
        status: 'Validado',
        verifiedBy: selectedSignature,
        verifiedAt: new Date().toISOString(),
        observations: input.observations,
        history: existingIdx > -1 ? updatedResults[existingIdx].history : []
      };

      if (existingIdx > -1) {
        updatedResults[existingIdx] = resItem;
      } else {
        updatedResults.push(resItem);
      }
    });

    onUpdateResults(updatedResults);
    onUpdateOrderStatus(selectedOrder.orderNumber, 'Validado');
    onAddAuditLog('Resultados - Validación', `Validó y firmó digitalmente la orden ${selectedOrder.orderNumber} con la firma de: ${selectedSignature}`);

    alert('¡Resultados validados y firmados con éxito! La orden está lista para el reporte en PDF.');
    
    onSelectOrderForReport(selectedOrder);
    onNavigate('reportes');
  };

  return (
    <div className="space-y-4">
      {/* Title */}
      <div className="bg-white border border-slate-200 px-4 py-3 rounded-lg flex items-center justify-between">
        <div>
          <h1 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Ingreso y Validación de Resultados</h1>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Registre los valores analíticos, asocie firmas electrónicas profesionales y revise el historial permanente de auditoría del LIS.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left column: Orders list */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Bandeja de Trabajo</h3>

            {/* Quick search & filter */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
                <input
                  id="results_search_order"
                  type="text"
                  placeholder="Buscar paciente o número..."
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-md text-xs focus:outline-hidden text-slate-800"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div className="flex gap-1 bg-slate-100 p-0.5 rounded text-[10px] font-bold text-slate-600">
                {(['Todos', 'Pendiente', 'Completado', 'Validado'] as const).map(f => (
                  <button
                    id={`res_filter_` + f}
                    key={f}
                    onClick={() => setOrderFilter(f)}
                    className={`flex-1 py-1 rounded transition-all cursor-pointer ${
                      orderFilter === f ? 'bg-white shadow-3xs text-slate-900 font-bold' : 'hover:bg-slate-50'
                    }`}
                  >
                    {f === 'Completado' ? 'Listo p/ Firmar' : f}
                  </button>
                ))}
              </div>
            </div>

            {/* Orders list container */}
            <div className="space-y-1.5 max-h-[440px] overflow-y-auto pr-1 divide-y divide-slate-100">
              {filteredOrders.map(order => {
                const isSelected = order.orderNumber === selectedOrderNumber;
                return (
                  <button
                    id={`res_select_order_` + order.orderNumber}
                    key={order.orderNumber}
                    onClick={() => handleSelectOrder(order)}
                    className={`w-full text-left p-2.5 rounded-md border transition-all flex justify-between items-start cursor-pointer ${
                      isSelected 
                        ? 'bg-blue-50/70 border-blue-200 shadow-3xs' 
                        : 'border-transparent hover:bg-slate-50'
                    }`}
                  >
                    <div className="space-y-1 truncate pr-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] font-bold text-slate-500">{order.orderNumber}</span>
                        <span className={`inline-block px-1 py-0.2 text-[8px] font-black rounded ${
                          order.status === 'Validado' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                          order.status === 'Completado' ? 'bg-blue-50 text-blue-800 border border-blue-200' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {order.status === 'Completado' ? 'Listo' : order.status}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 truncate">{order.patientName}</h4>
                      <p className="text-[10px] text-slate-450">Dr. {order.doctorName}</p>
                      <div className="text-[9px] text-slate-500 font-semibold space-y-0.5 mt-1">
                        <div>Entrada: <span className="font-mono text-slate-700">{getOrderTimes(order).entry}</span></div>
                        <div>Entrega: <span className="font-mono text-slate-700">{getOrderTimes(order).delivery}</span></div>
                      </div>
                    </div>
                    <div className="text-right text-[10px] text-slate-400 flex flex-col items-end gap-1 shrink-0">
                      <span>{new Date(order.createdAt).toLocaleDateString('es-SV')}</span>
                      <span className="bg-slate-100 text-slate-700 px-1 py-0.2 rounded font-mono font-bold text-[9px]">
                        {order.examCodes.length} exp.
                      </span>
                    </div>
                  </button>
                );
              })}
              {filteredOrders.length === 0 && (
                <div className="text-center py-10 text-xs text-slate-400 font-semibold">
                  No se encontraron órdenes para este filtro.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right column: Results Entry worksheet */}
        <div className="lg:col-span-8">
          {selectedOrder ? (
            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-4">
              {/* Patient header info */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-3 border-b border-slate-200 gap-2">
                <div>
                  <span className="text-[9px] font-extrabold uppercase tracking-widest bg-slate-100 text-slate-650 px-1.5 py-0.5 rounded">
                    Resultados de la Orden
                  </span>
                  <h3 className="text-sm font-black text-slate-900 mt-1.5">{selectedOrder.patientName}</h3>
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-[11px] text-slate-500 mt-2 font-medium bg-slate-50 p-2 rounded border border-slate-100">
                    <span>Edad: <strong className="text-slate-700">{selectedOrder.patientAge} años</strong></span>
                    <span>Género: <strong className="text-slate-700">{selectedOrder.patientGender === 'M' ? 'Masculino' : 'Femenino'}</strong></span>
                    <span>Médico: <strong className="text-slate-700">{selectedOrder.doctorName}</strong></span>
                    <span className="border-l border-slate-250 pl-3">Tiempo de Entrada: <strong className="text-blue-700 font-mono">{getOrderTimes(selectedOrder).entry}</strong></span>
                    <span className="border-l border-slate-250 pl-3">Tiempo de Entrega: <strong className="text-emerald-700 font-mono">{getOrderTimes(selectedOrder).delivery}</strong></span>
                  </div>
                </div>
                <div className="text-right flex flex-col items-end gap-0.5">
                  <span className="font-mono text-xs font-black text-blue-600">{selectedOrder.orderNumber}</span>
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Planilla de Ensayos</span>
                </div>
              </div>

              {/* Results worksheet table */}
              <div className="space-y-3">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ensayos Clínicos Asignados</div>
                <div className="space-y-2.5">
                  {selectedOrder.examCodes.map(code => {
                    const exam = exams.find(e => e.code === code);
                    const ref = findReferenceRange(code, selectedOrder.patientAge, selectedOrder.patientGender);
                    const resultValue = activeWorksheet[code]?.value || '';
                    const resultObs = activeWorksheet[code]?.observations || '';
                    const existingRes = results.find(r => r.orderNumber === selectedOrder.orderNumber && r.examCode === code);

                    return (
                      <div key={code} className="p-3 bg-slate-50/50 rounded-lg border border-slate-200 space-y-2.5">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="font-mono text-[9px] font-bold text-blue-600 mr-2 uppercase">{code}</span>
                            <span className="font-bold text-xs text-slate-900">{exam?.name}</span>
                            <p className="text-[10px] text-slate-400">Método: {exam?.method}</p>
                          </div>
                          
                          {/* Reference Range info */}
                          <div className="text-right text-[11px] text-slate-650 font-medium">
                            <span className="font-bold text-slate-400 block uppercase text-[8px] tracking-wider">Rango de Referencia</span>
                            {ref ? (
                              ref.valMin !== null && ref.valMax !== null ? (
                                <p>Normal: <span className="font-mono font-bold text-slate-900">{ref.valMin} - {ref.valMax}</span> {ref.unit}</p>
                              ) : ref.textReference ? (
                                <p className="truncate font-bold text-slate-800" title={ref.textReference}>{ref.textReference}</p>
                              ) : (
                                <p className="italic text-slate-400">Sin rango</p>
                              )
                            ) : (
                              <p className="italic text-slate-400">Sin rango</p>
                            )}
                          </div>
                        </div>

                        {/* Result input fields */}
                        {code === 'HEM01' || code === 'EGO01' || code === 'EGC01' || code === 'EGH01' ? (
                          renderCustomStructuredForm(code, resultValue, selectedOrder.status === 'Validado')
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
                            <div className="md:col-span-5">
                              <input
                                id={`input_val_` + code}
                                type="text"
                                disabled={selectedOrder.status === 'Validado'}
                                placeholder="Reportar valor obtenido..."
                                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 font-bold text-slate-900 disabled:bg-slate-100 disabled:text-slate-500"
                                value={resultValue}
                                onChange={(e) => handleValueChange(code, e.target.value)}
                              />
                            </div>

                            <div className="md:col-span-5">
                              <input
                                id={`input_obs_` + code}
                                type="text"
                                disabled={selectedOrder.status === 'Validado'}
                                placeholder="Observaciones o notas clínicas..."
                                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-hidden focus:border-blue-500 text-slate-600 disabled:bg-slate-100 disabled:text-slate-500"
                                value={resultObs}
                                onChange={(e) => handleObservationsChange(code, e.target.value)}
                              />
                            </div>

                            {/* History triggers */}
                            <div className="md:col-span-2 text-center flex justify-center gap-1 shrink-0">
                              {existingRes && existingRes.history && existingRes.history.length > 0 ? (
                                <button
                                  id={`btn_hist_` + code}
                                  onClick={() => setShowHistoryForExamCode(showHistoryForExamCode === code ? null : code)}
                                  className="p-1.5 bg-white border border-slate-200 hover:border-emerald-450 hover:bg-emerald-50 text-slate-500 hover:text-emerald-750 rounded transition-colors flex items-center justify-center cursor-pointer"
                                  title="Ver historial de modificaciones"
                                >
                                  <History className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <span className="text-[10px] text-slate-350 italic font-medium">Sin cambios</span>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Render Modification History details block if clicked */}
                        {showHistoryForExamCode === code && existingRes && (
                          <div className="p-2.5 bg-white border border-slate-200 rounded-md space-y-2 text-[11px] font-medium">
                            <div className="font-bold text-slate-700 border-b border-slate-100 pb-1">Auditoría de Cambios ({code})</div>
                            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                              {existingRes.history.map((hist, hIdx) => (
                                <div key={hist.id || hIdx} className="border-l-2 border-amber-300 pl-2 py-0.5 space-y-0.5">
                                  <div className="flex justify-between text-[10px] text-slate-400 font-bold">
                                    <span>{hist.modifiedBy}</span>
                                    <span>{new Date(hist.modifiedAt).toLocaleTimeString('es-SV')}</span>
                                  </div>
                                  <p className="text-slate-800">Valor: <span className="font-black text-red-600">"{hist.oldValue}"</span> → <span className="font-black text-emerald-600">"{hist.newValue}"</span></p>
                                  {hist.reason && <p className="text-slate-450 text-[10px]">Razón: <span className="italic">{hist.reason}</span></p>}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Reason for modification box */}
              {selectedOrder.status !== 'Validado' && (
                <div className="p-3 bg-amber-50 rounded-md border border-amber-200 space-y-1.5">
                  <h4 className="text-[11px] font-bold text-amber-800 flex items-center gap-1.5 uppercase tracking-wide">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    Motivo de Modificación (Auditoría LIS)
                  </h4>
                  <p className="text-[10px] text-amber-700 leading-relaxed font-medium">
                    Obligatorio para documentar cambios en resultados de análisis que ya poseían valores guardados previamente.
                  </p>
                  <input
                    id="res_change_reason"
                    type="text"
                    placeholder="e.g. Confirmación por reanalizador / Corrección de dedo..."
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-amber-200 rounded-md focus:outline-hidden text-slate-700 font-semibold"
                    value={reasonForChange}
                    onChange={(e) => setReasonForChange(e.target.value)}
                  />
                </div>
              )}

              {/* Digital Stamp and Signature Box */}
              <div className="pt-4 border-t border-slate-150">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-600 mb-1 uppercase tracking-wide">Firma Responsable Autorizada</label>
                    <select
                      id="res_select_sig"
                      disabled={selectedOrder.status === 'Validado'}
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-slate-700 disabled:bg-slate-100 disabled:text-slate-500 font-bold"
                      value={selectedSignature}
                      onChange={(e) => setSelectedSignature(e.target.value)}
                    >
                      <option value="">-- Seleccionar Firma Profesional --</option>
                      <option value="Dr. Roberto Solís - Reg. JVPM 8492">Dr. Roberto Solís - Reg. JVPM 8492 (Director)</option>
                      <option value="Lic. Andrea Mendoza - Reg. JVPLC 3541">Lic. Andrea Mendoza - Reg. JVPLC 3541 (Tecnólogo)</option>
                    </select>
                  </div>

                  {/* Stamp representation */}
                  <div className="flex justify-end">
                    {selectedSignature ? (
                      <div className="p-2.5 bg-blue-50/70 border border-dashed border-blue-300 rounded-md text-center space-y-0.5 w-full max-w-xs flex flex-col justify-center items-center">
                        <Award className="w-4 h-4 text-blue-600 animate-bounce" />
                        <span className="text-[8px] font-black text-blue-800 tracking-widest uppercase block">Sello Digital LIS El Salvador</span>
                        <p className="text-[10px] font-black text-slate-800 italic">"{selectedSignature}"</p>
                        <p className="text-[7px] text-slate-400 font-bold">Autenticado Clínicamente</p>
                      </div>
                    ) : (
                      <div className="p-3 bg-slate-50 rounded-md text-center text-[10px] text-slate-400 w-full max-w-xs border border-slate-200 py-4 font-semibold">
                        Seleccione una firma para habilitar el sello clínico.
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Save / Validate buttons */}
              <div className="flex gap-2.5 pt-3 border-t border-slate-150">
                {selectedOrder.status !== 'Validado' ? (
                  <>
                    <button
                      id="btn_res_save_draft"
                      onClick={handleSaveDraft}
                      className="flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-md transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-slate-250"
                    >
                      <Save className="w-3.5 h-3.5" /> Guardar Borrador
                    </button>
                    <button
                      id="btn_res_validate"
                      onClick={handleValidateAndSign}
                      className="flex-1 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" /> Validar y Firmar
                    </button>
                  </>
                ) : (
                  <div className="w-full flex items-center justify-between p-2.5 bg-emerald-50 rounded-md border border-emerald-200">
                    <span className="text-[11px] text-emerald-800 font-bold flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      Resultados validados y firmados irrevocablemente.
                    </span>
                    <button
                      id="btn_res_to_pdf"
                      onClick={() => {
                        onSelectOrderForReport(selectedOrder);
                        onNavigate('reportes');
                      }}
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded cursor-pointer"
                    >
                      Ver PDF
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 border border-dashed border-slate-300 rounded-lg p-10 text-center text-slate-400 flex flex-col items-center justify-center gap-2">
              <FileSpreadsheet className="w-10 h-10 text-slate-300" />
              <h3 className="font-sans font-bold text-slate-700 text-xs uppercase tracking-wide">Sin orden seleccionada</h3>
              <p className="text-[11px] text-slate-400 max-w-xs leading-relaxed font-semibold">
                Seleccione un expediente de la bandeja de trabajo izquierda para registrar los valores analíticos.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
