/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  Binary, 
  FileSpreadsheet, 
  FileText, 
  Settings, 
  Activity, 
  Clock, 
  Lock, 
  Menu, 
  X, 
  User as UserIcon,
  ShieldCheck,
  Search,
  Bell
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { Patient, Order, Exam, ReferenceRange, ExamResult, User, AuditLog } from './types/lis';
import { 
  INITIAL_PATIENTS, 
  INITIAL_ORDERS, 
  INITIAL_EXAMS, 
  INITIAL_REFERENCE_RANGES, 
  INITIAL_RESULTS, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_USERS 
} from './data/initialData';

import Dashboard from './components/Dashboard';
import Reception from './components/Reception';
import Catalog from './components/Catalog';
import ReferenceValues from './components/ReferenceValues';
import ResultsEntry from './components/ResultsEntry';
import Reports from './components/Reports';
import Administration from './components/Administration';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Core Database States (Synchronized with express backend and fallback to initial data)
  const [patients, setPatients] = useState<Patient[]>(INITIAL_PATIENTS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [exams, setExams] = useState<Exam[]>(INITIAL_EXAMS);
  const [referenceRanges, setReferenceRanges] = useState<ReferenceRange[]>(INITIAL_REFERENCE_RANGES);
  const [results, setResults] = useState<ExamResult[]>(INITIAL_RESULTS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]);

  // Customizable Letterhead State
  const [letterhead, setLetterhead] = useState({
    labName: "Laboratorio Clínico MONTEHOREB",
    slogan: "Experiencia y Calidad en la que puedes Confiar",
    cssp: "C.S.S.P No. 1716",
    address: "3a. Calle Oriente, entre 9a. y 11 Av. Sur, No. 57, Barrio Apaneca Chalchuapa, Departamento de Santa Ana.",
    phoneCell: "7129-8475",
    phoneLandline: "2408-2913",
    ownerName: "Licda. Marta Lilian Madrid de Ruiz",
    jvplc: "J.V.P.L.C No. 2661",
    stampLines: [
      "República de El Salvador",
      "C. S. S. P.",
      "LABORATORIO CLINICO MONTEHOREB",
      "Nº Inscripción 1716",
      "Prop. Licda. Marta Lilian de Ruiz",
      "Chalchuapa, Santa Ana"
    ]
  });

  // Simplified Single User Login State
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem('lis_logged_in') === 'true';
  });
  
  const [isSyncing, setIsSyncing] = useState(false);

  // Fetch full state from backend
  const fetchState = async () => {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data = await res.json();
        if (data && data.patients) {
          setPatients(data.patients);
          setOrders(data.orders);
          setExams(data.exams);
          setReferenceRanges(data.referenceRanges);
          setResults(data.results);
          setAuditLogs(data.auditLogs);
          setUsers(data.users);
          if (data.letterhead) {
            setLetterhead(data.letterhead);
          }
        }
      }
    } catch (e) {
      console.error("Error fetching state:", e);
    }
  };

  // Sync updates to backend
  const syncState = async (updates: any) => {
    setIsSyncing(true);
    try {
      const res = await fetch('/api/state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        const data = await res.json();
        if (data && data.patients) {
          setPatients(data.patients);
          setOrders(data.orders);
          setExams(data.exams);
          setReferenceRanges(data.referenceRanges);
          setResults(data.results);
          setAuditLogs(data.auditLogs);
          setUsers(data.users);
          if (data.letterhead) {
            setLetterhead(data.letterhead);
          }
        }
      }
    } catch (e) {
      console.error("Error syncing state:", e);
    } finally {
      setIsSyncing(false);
    }
  };

  // Initial fetch and polling loop for cross-device instant synchronization
  useEffect(() => {
    fetchState();
    const interval = setInterval(() => {
      fetchState();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Sync fallback cache
  useEffect(() => {
    localStorage.setItem('lis_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  // Flow State
  const [selectedOrderForReport, setSelectedOrderForReport] = useState<Order | null>(null);

  // Top Bar Search State
  const [headerSearchQuery, setHeaderSearchQuery] = useState('');
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  // Filter patients and orders in real-time
  const headerSearchResults = useMemo(() => {
    if (!headerSearchQuery.trim()) return [];
    const query = headerSearchQuery.toLowerCase();

    const matchingPatients = patients.filter(p => 
      p.name.toLowerCase().includes(query) || (p.dui && p.dui.toLowerCase().includes(query))
    ).map(p => ({ 
      type: 'paciente' as const, 
      id: p.id, 
      title: p.name, 
      subtitle: `Paciente • DUI: ${p.dui || 'N/A'}` 
    }));

    const matchingOrders = orders.filter(o => 
      o.orderNumber.toLowerCase().includes(query) || o.patientName.toLowerCase().includes(query)
    ).map(o => ({ 
      type: 'orden' as const, 
      id: o.orderNumber, 
      title: o.orderNumber, 
      subtitle: `Orden • ${o.patientName} (${o.status})`,
      raw: o
    }));

    return [...matchingPatients, ...matchingOrders].slice(0, 5);
  }, [headerSearchQuery, patients, orders]);

  // Append new audit log helper
  const handleAddAuditLog = (action: string, details: string) => {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      username: currentUser.username,
      role: currentUser.role,
      action,
      details,
      ipAddress: "192.168.1.12"
    };
    const updated = [newLog, ...auditLogs];
    setAuditLogs(updated);
    syncState({ auditLogs: updated });
  };

  // State mutations
  const handleAddPatient = (patient: Patient) => {
    const updated = [...patients, patient];
    setPatients(updated);
    syncState({ patients: updated });
  };

  const handleCreateOrder = (order: Order) => {
    const updated = [...orders, order];
    setOrders(updated);
    syncState({ orders: updated });
  };

  const handleUpdateExams = (updatedExams: Exam[]) => {
    setExams(updatedExams);
    syncState({ exams: updatedExams });
  };

  const handleUpdateReferenceRanges = (updatedRanges: ReferenceRange[]) => {
    setReferenceRanges(updatedRanges);
    syncState({ referenceRanges: updatedRanges });
  };

  const handleUpdateResults = (updatedResults: ExamResult[]) => {
    setResults(updatedResults);
    syncState({ results: updatedResults });
  };

  const handleUpdateOrderStatus = (orderNumber: string, status: 'Pendiente' | 'Completado' | 'Validado') => {
    const updated = orders.map(o => o.orderNumber === orderNumber ? { ...o, status } : o);
    setOrders(updated);
    syncState({ orders: updated });
  };

  const handleRestoreDatabase = (dbState: {
    patients: Patient[];
    orders: Order[];
    exams: Exam[];
    auditLogs: AuditLog[];
  }) => {
    setPatients(dbState.patients);
    setOrders(dbState.orders);
    setExams(dbState.exams);
    setAuditLogs(dbState.auditLogs);
    syncState({
      patients: dbState.patients,
      orders: dbState.orders,
      exams: dbState.exams,
      auditLogs: dbState.auditLogs
    });
    setSelectedOrderForReport(null);
  };

  const handleUpdateLetterhead = (newConfig: any) => {
    setLetterhead(newConfig);
    syncState({ letterhead: newConfig });
  };

  // Login Form State
  const [loginUsername, setLoginUsername] = useState('admin');
  const [loginPassword, setLoginPassword] = useState('admin');
  const [loginError, setLoginError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginUsername === 'admin' && loginPassword === 'admin') {
      setIsLoggedIn(true);
      localStorage.setItem('lis_logged_in', 'true');
      setLoginError('');
      const adminUser = users.find(u => u.username === 'admin') || INITIAL_USERS[0];
      setCurrentUser(adminUser);
      
      // Since logs are synced, we append log directly and sync
      const newLog: AuditLog = {
        id: `LOG-${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: adminUser.id,
        username: adminUser.username,
        role: adminUser.role,
        action: 'Inicio de Sesión',
        details: `Usuario ${adminUser.name} inició sesión exitosamente (Acceso Único).`,
        ipAddress: "192.168.1.12"
      };
      const updatedLogs = [newLog, ...auditLogs];
      setAuditLogs(updatedLogs);
      syncState({ auditLogs: updatedLogs });
    } else {
      setLoginError('Credenciales incorrectas. Para facilidad de uso, ingrese usuario: admin y clave: admin');
    }
  };

  const handleLogout = () => {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      username: currentUser.username,
      role: currentUser.role,
      action: 'Cierre de Sesión',
      details: `Usuario ${currentUser.name} cerró la sesión activa.`,
      ipAddress: "192.168.1.12"
    };
    const updatedLogs = [newLog, ...auditLogs];
    setAuditLogs(updatedLogs);
    setIsLoggedIn(false);
    localStorage.removeItem('lis_logged_in');
    syncState({ auditLogs: updatedLogs });
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 antialiased selection:bg-blue-600 selection:text-white">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-8 space-y-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1.5 bg-blue-600"></div>
          
          <div className="text-center space-y-2">
            <div className="mx-auto w-12 h-12 bg-blue-600/10 rounded-xl flex items-center justify-center text-blue-500 border border-blue-500/20">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <h1 className="text-sm font-black text-white uppercase tracking-tight">{letterhead.labName}</h1>
            <p className="text-[10px] text-slate-400 font-medium">{letterhead.slogan}</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {loginError && (
              <div className="p-3 bg-red-900/30 border border-red-500/20 text-red-200 text-[10px] font-bold rounded-lg text-center uppercase tracking-wide">
                {loginError}
              </div>
            )}

            <div className="space-y-1">
              <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Usuario LIS</label>
              <input
                type="text"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 text-white rounded-lg focus:outline-hidden text-xs font-bold focus:border-blue-500 transition-colors placeholder:text-slate-700"
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                placeholder="admin"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Contraseña de Acceso</label>
              <input
                type="password"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 text-white rounded-lg focus:outline-hidden text-xs font-bold focus:border-blue-500 transition-colors placeholder:text-slate-700"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs uppercase tracking-widest rounded-lg shadow-lg shadow-blue-900/30 transition-all cursor-pointer"
            >
              Iniciar Sesión LIS
            </button>
          </form>

          <div className="pt-2 border-t border-slate-800 text-center">
            <p className="text-[9px] text-slate-500 font-medium">
              Acceso restringido para personal autorizado de {letterhead.labName}.
            </p>
            <p className="text-[9px] text-blue-500/70 font-semibold mt-1">
              Sugerencia de acceso rápido: admin / admin
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex text-slate-900 antialiased font-sans">
      {/* Sidebar Navigation - Desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-[#1E293B] text-slate-300 border-r border-slate-700 shrink-0">
        {/* Brand Header */}
        <div className="p-4 border-b border-slate-700 flex items-center gap-2.5">
          <Activity className="w-5 h-5 text-blue-400 animate-pulse" />
          <div>
            <h1 className="text-xs font-extrabold text-white tracking-widest uppercase">BioLab LIS v4.0</h1>
            <p className="text-[9px] text-slate-400 font-semibold tracking-wider uppercase">Lab Clínico El Salvador</p>
          </div>
        </div>

        {/* Menu Options */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-3 mb-1.5 mt-2">OPERACIONES LIS</div>
          <button
            id="nav_dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
              activeTab === 'dashboard' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30 font-semibold' : 'text-slate-400 hover:bg-slate-800 hover:text-white font-medium border border-transparent'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" /> Panel Principal
          </button>

          <button
            id="nav_recepcion"
            onClick={() => setActiveTab('recepcion')}
            className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
              activeTab === 'recepcion' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30 font-semibold' : 'text-slate-400 hover:bg-slate-800 hover:text-white font-medium border border-transparent'
            }`}
          >
            <Users className="w-3.5 h-3.5" /> Recepción y Admisión
          </button>

          <button
            id="nav_results"
            onClick={() => setActiveTab('resultados')}
            className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
              activeTab === 'resultados' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30 font-semibold' : 'text-slate-400 hover:bg-slate-800 hover:text-white font-medium border border-transparent'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" /> Laboratorio / Resultados
          </button>

          <button
            id="nav_reports"
            onClick={() => setActiveTab('reportes')}
            className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
              activeTab === 'reportes' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30 font-semibold' : 'text-slate-400 hover:bg-slate-800 hover:text-white font-medium border border-transparent'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Certificados y PDF
          </button>

          <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-3 mb-1.5 mt-4">CATÁLOGOS & REF</div>

          <button
            id="nav_catalog"
            onClick={() => setActiveTab('catalogo')}
            className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
              activeTab === 'catalogo' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30 font-semibold' : 'text-slate-400 hover:bg-slate-800 hover:text-white font-medium border border-transparent'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> Catálogo de Exámenes
          </button>

          <button
            id="nav_ref_ranges"
            onClick={() => setActiveTab('valores_referencia')}
            className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
              activeTab === 'valores_referencia' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30 font-semibold' : 'text-slate-400 hover:bg-slate-800 hover:text-white font-medium border border-transparent'
            }`}
          >
            <Binary className="w-3.5 h-3.5" /> Rangos de Referencia
          </button>

          <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-3 mb-1.5 mt-4">ADMINISTRACIÓN</div>

          <button
            id="nav_admin"
            onClick={() => setActiveTab('administracion')}
            className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
              activeTab === 'administracion' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30 font-semibold' : 'text-slate-400 hover:bg-slate-800 hover:text-white font-medium border border-transparent'
            }`}
          >
            <Settings className="w-3.5 h-3.5" /> Seguridad y Auditoría
          </button>
        </nav>

        {/* Current user footer badge */}
        <div className="p-3 bg-slate-900/60 border-t border-slate-700 flex flex-col gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-blue-600/80 rounded-md flex items-center justify-center text-white font-extrabold font-mono text-xs shrink-0">
              {currentUser.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
            </div>
            <div className="truncate text-xs flex-1">
              <span className="font-bold text-white block truncate text-[11px] leading-tight">{currentUser.name}</span>
              <span className="text-[9px] text-slate-400 font-semibold block uppercase tracking-wider mt-0.5">{currentUser.role}</span>
            </div>
          </div>
          <button
            id="lis_sidebar_logout_btn"
            onClick={handleLogout}
            className="w-full py-1.5 text-center bg-red-600/90 hover:bg-red-700 text-white font-extrabold text-[9px] uppercase tracking-wider rounded transition-colors cursor-pointer border border-red-500/10 shadow-3xs"
          >
            Cerrar Sesión Activa
          </button>
        </div>
      </aside>

      {/* Main Panel Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-x-hidden">
        {/* Top Header Bar */}
        <header className="sticky top-0 bg-white border-b border-slate-200 h-14 px-6 flex justify-between items-center z-30 shadow-2xs">
          <div className="flex items-center gap-3">
            {/* Mobile burger toggle */}
            <button
              id="mobile_burger_toggle"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              <Menu className="w-4 h-4" />
            </button>
            
            {/* High density search bar */}
            <div className="relative hidden md:block">
              <div className="flex items-center bg-slate-100 rounded-lg px-2.5 py-1 w-80 border border-slate-200">
                <Search className="w-3.5 h-3.5 text-slate-400 mr-2" />
                <input
                  id="global_header_search"
                  type="text"
                  placeholder="Buscar paciente o código de orden..."
                  className="bg-transparent border-none text-xs w-full focus:outline-hidden text-slate-800 placeholder-slate-400 p-0"
                  value={headerSearchQuery}
                  onChange={(e) => {
                    setHeaderSearchQuery(e.target.value);
                    setShowSearchDropdown(true);
                  }}
                  onFocus={() => setShowSearchDropdown(true)}
                />
                {headerSearchQuery && (
                  <button 
                    onClick={() => { setHeaderSearchQuery(''); setShowSearchDropdown(false); }}
                    className="text-slate-400 hover:text-slate-600 text-xs font-semibold cursor-pointer ml-1 animate-fade-in"
                  >
                    ×
                  </button>
                )}
              </div>

              {/* Real-time search results dropdown */}
              {showSearchDropdown && headerSearchQuery && (
                <div className="absolute left-0 mt-1.5 w-80 bg-white border border-slate-200 rounded-lg shadow-lg z-50 divide-y divide-slate-100 max-h-60 overflow-y-auto">
                  {headerSearchResults.length > 0 ? (
                    headerSearchResults.map((res) => (
                      <button
                        key={res.id}
                        className="w-full text-left px-3 py-2 hover:bg-slate-50 flex flex-col cursor-pointer"
                        onClick={() => {
                          if (res.type === 'paciente') {
                            setActiveTab('recepcion');
                          } else if (res.type === 'orden') {
                            setSelectedOrderForReport(res.raw);
                            setActiveTab('reportes');
                          }
                          setHeaderSearchQuery('');
                          setShowSearchDropdown(false);
                        }}
                      >
                        <span className="text-xs font-semibold text-slate-800">{res.title}</span>
                        <span className="text-[10px] text-slate-400 font-medium">{res.subtitle}</span>
                      </button>
                    ))
                  ) : (
                    <div className="p-2.5 text-center text-slate-400 text-[11px]">
                      No hay coincidencias en el LIS
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-[10px] font-mono bg-emerald-50 text-emerald-700 px-2.5 py-0.5 rounded-full border border-emerald-200">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
              <span>Equipos LIS Conectados (3/3)</span>
            </div>

            <div className="h-4 w-[1px] bg-slate-200"></div>

            <div className="flex items-center gap-3">
              <div className="text-right text-[10px] text-slate-500 hidden sm:block">
                <span className="font-bold block text-slate-700 leading-tight">Estación Central</span>
                <span className="font-mono text-slate-400">IP: 192.168.1.12</span>
              </div>
              <button 
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 relative cursor-pointer"
                onClick={() => alert('No hay notificaciones pendientes')}
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-0 right-0 w-2 h-2 bg-blue-500 rounded-full border-2 border-white"></span>
              </button>
            </div>
          </div>
        </header>

        {/* Dynamic active view container */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-7xl w-full mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              {activeTab === 'dashboard' && (
                <Dashboard
                  patients={patients}
                  orders={orders}
                  results={results}
                  auditLogs={auditLogs}
                  onNavigate={setActiveTab}
                  onSelectOrder={(order) => {
                    setSelectedOrderForReport(order);
                  }}
                />
              )}

              {activeTab === 'recepcion' && (
                <Reception
                  patients={patients}
                  exams={exams}
                  onAddPatient={handleAddPatient}
                  onCreateOrder={handleCreateOrder}
                  onAddAuditLog={handleAddAuditLog}
                />
              )}

              {activeTab === 'catalogo' && (
                <Catalog
                  exams={exams}
                  onUpdateExams={handleUpdateExams}
                  onAddAuditLog={handleAddAuditLog}
                />
              )}

              {activeTab === 'valores_referencia' && (
                <ReferenceValues
                  referenceRanges={referenceRanges}
                  exams={exams}
                  onUpdateRanges={handleUpdateReferenceRanges}
                  onAddAuditLog={handleAddAuditLog}
                />
              )}

              {activeTab === 'resultados' && (
                <ResultsEntry
                  orders={orders}
                  exams={exams}
                  results={results}
                  referenceRanges={referenceRanges}
                  currentUser={currentUser}
                  onUpdateResults={handleUpdateResults}
                  onUpdateOrderStatus={handleUpdateOrderStatus}
                  onAddAuditLog={handleAddAuditLog}
                  onSelectOrderForReport={setSelectedOrderForReport}
                  onNavigate={setActiveTab}
                />
              )}

              {activeTab === 'reportes' && (
                <Reports
                  orders={orders}
                  exams={exams}
                  results={results}
                  referenceRanges={referenceRanges}
                  patients={patients}
                  selectedOrder={selectedOrderForReport}
                  onSelectOrder={setSelectedOrderForReport}
                  onAddAuditLog={handleAddAuditLog}
                  letterhead={letterhead}
                />
              )}

              {activeTab === 'administracion' && (
                <Administration
                  users={users}
                  auditLogs={auditLogs}
                  orders={orders}
                  patients={patients}
                  exams={exams}
                  currentUser={currentUser}
                  onUpdateCurrentUser={setCurrentUser}
                  onUpdateUsers={setUsers}
                  onRestoreDatabase={handleRestoreDatabase}
                  onAddAuditLog={handleAddAuditLog}
                  letterhead={letterhead}
                  onUpdateLetterhead={handleUpdateLetterhead}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Bottom Taskbar */}
        <footer className="h-9 bg-white border-t border-slate-200 px-6 flex items-center justify-between text-[10px] text-slate-500 font-medium shrink-0">
          <div className="flex space-x-6 text-slate-400">
            <span>© 2026 BioLab LIS El Salvador. Todos los derechos reservados.</span>
            <span>Estación IP: 192.168.1.12</span>
            <span className="text-emerald-600 font-bold">DB: Conectado (PostgreSQL Active)</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-400">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="uppercase tracking-widest text-[9px] font-semibold">Servidor Operacional Online</span>
          </div>
        </footer>
      </div>

      {/* Mobile Drawer Navigation Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-slate-950/80 z-50 lg:hidden flex">
          <aside className="w-64 bg-slate-900 text-slate-300 p-6 flex flex-col h-full space-y-6">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-6 h-6 text-blue-500 animate-pulse" />
                <span className="font-extrabold text-white text-sm tracking-widest uppercase">LIS Salvador</span>
              </div>
              <button
                id="close_mobile_menu_btn"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <nav className="flex-1 space-y-1">
              <button
                id="mob_nav_dash"
                onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'dashboard' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" /> Panel Principal
              </button>
              <button
                id="mob_nav_recep"
                onClick={() => { setActiveTab('recepcion'); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'recepcion' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                }`}
              >
                <Users className="w-4 h-4" /> Recepción y Muestras
              </button>
              <button
                id="mob_nav_cat"
                onClick={() => { setActiveTab('catalogo'); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'catalogo' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                }`}
              >
                <BookOpen className="w-4 h-4" /> Catálogo de Exámenes
              </button>
              <button
                id="mob_nav_ref"
                onClick={() => { setActiveTab('valores_referencia'); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'valores_referencia' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                }`}
              >
                <Binary className="w-4 h-4" /> Valores de Referencia
              </button>
              <button
                id="mob_nav_res"
                onClick={() => { setActiveTab('resultados'); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'resultados' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                }`}
              >
                <FileSpreadsheet className="w-4 h-4" /> Laboratorio / Resultados
              </button>
              <button
                id="mob_nav_rep"
                onClick={() => { setActiveTab('reportes'); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'reportes' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                }`}
              >
                <FileText className="w-4 h-4" /> Certificados y PDF
              </button>
              <button
                id="mob_nav_admin"
                onClick={() => { setActiveTab('administracion'); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'administracion' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                }`}
              >
                <Settings className="w-4 h-4" /> Seguridad & Auditoría
              </button>
            </nav>

            <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-3 rounded-xl">
              <div className="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center text-white font-bold text-xs">
                {currentUser.name[0]}
              </div>
              <div className="truncate text-xs">
                <span className="font-bold text-white block truncate">{currentUser.name}</span>
                <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">{currentUser.role}</span>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
