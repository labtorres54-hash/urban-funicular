/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Patient {
  id: string; // e.g., PAT-1001
  name: string;
  dui: string; // e.g., 01234567-8
  phone: string;
  email: string;
  birthDate: string;
  gender: 'M' | 'F' | 'Otro';
  createdAt: string;
}

export interface Exam {
  code: string; // e.g., HEM01
  name: string;
  area: string; // e.g., Hematología, Química, Coprología, Uroanálisis
  price: number;
  unit: string; // e.g., g/dL, mg/dL
  method: string; // e.g., Automatizado, Espectrofotometría, Manual
  deliveryTime: string; // e.g., 4 horas, 24 horas
  priceHistory?: { date: string; price: number }[];
}

export interface ReferenceRange {
  id: string;
  examCode: string;
  ageMin: number; // in years
  ageMax: number; // in years
  sex: 'M' | 'F' | 'Todos';
  unit: string;
  valMin: number | null;
  valMax: number | null;
  textReference?: string; // for qualitative exams like "Negativo"
  observations?: string;
}

export interface Order {
  orderNumber: string; // e.g., ORD-2026-0001
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: 'M' | 'F' | 'Otro';
  doctorName: string;
  status: 'Pendiente' | 'Completado' | 'Validado';
  paymentStatus: 'Pagado' | 'Pendiente' | 'Exento';
  examCodes: string[];
  createdAt: string;
  totalAmount: number;
}

export interface ResultHistoryItem {
  id: string;
  modifiedBy: string;
  modifiedAt: string;
  oldValue: string;
  newValue: string;
  reason?: string;
}

export interface ExamResult {
  id: string; // e.g., RES-1001
  orderNumber: string;
  examCode: string;
  value: string; // actual reported result, numeric or text
  status: 'Ingresado' | 'Validado';
  verifiedBy?: string; // professional digital signature holder
  verifiedAt?: string;
  observations?: string;
  modifiedBy?: string;
  modifiedAt?: string;
  history: ResultHistoryItem[];
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: 'Administrador' | 'Tecnólogo' | 'Recepcionista';
  signature?: string; // Digital signature representation (Base64 / SVG path/Text)
  active: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  username: string;
  role: string;
  action: string;
  details: string;
  ipAddress?: string;
}

export interface LetterheadConfig {
  labName: string;
  slogan: string;
  cssp: string;
  address: string;
  phoneCell: string;
  phoneLandline: string;
  ownerName: string;
  jvplc: string;
  stampLines: string[];
}

