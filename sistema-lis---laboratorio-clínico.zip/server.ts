import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

// Initial collections from initialData
import { 
  INITIAL_PATIENTS, 
  INITIAL_ORDERS, 
  INITIAL_EXAMS, 
  INITIAL_REFERENCE_RANGES, 
  INITIAL_RESULTS, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_USERS 
} from "./src/data/initialData";

const DB_FILE = path.join(process.cwd(), "db.json");

// Default Letterhead Config
const DEFAULT_LETTERHEAD = {
  labName: "Laboratorio Clínico MONTEHOREB",
  slogan: "Experiencia y Calidad en la que puedes Confiar",
  cssp: "C.S.S.P No. 1716",
  address: "3a. Calle Oriente, entre 9a. y 11 Av. Sur, No. 57, Barrio Apaneca Chalchuapa, Departamento de Santa Ana.",
  phoneCell: "7129-8475",
  phoneLandline: "2408-2913",
  ownerName: "Licda. Marta Lilian Madrid de Ruiz",
  jvplc: "J.V.P.L.C No. 2661",
  stampLines: [
    "República de El Salvador",
    "C. S. S. P.",
    "LABORATORIO CLINICO MONTEHOREB",
    "Nº Inscripción 1716",
    "Prop. Licda. Marta Lilian de Ruiz",
    "Chalchuapa, Santa Ana"
  ]
};

// Global DB State
let dbState = {
  patients: INITIAL_PATIENTS,
  orders: INITIAL_ORDERS,
  exams: INITIAL_EXAMS,
  referenceRanges: INITIAL_REFERENCE_RANGES,
  results: INITIAL_RESULTS,
  auditLogs: INITIAL_AUDIT_LOGS,
  users: INITIAL_USERS,
  letterhead: DEFAULT_LETTERHEAD
};

// Load existing DB if it exists
if (fs.existsSync(DB_FILE)) {
  try {
    const raw = fs.readFileSync(DB_FILE, "utf-8");
    const loaded = JSON.parse(raw);
    dbState = { ...dbState, ...loaded };
    console.log("Database loaded successfully from", DB_FILE);
  } catch (err) {
    console.error("Error reading database file, using defaults", err);
  }
} else {
  // Write initial DB file
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbState, null, 2), "utf-8");
    console.log("Initial database file written to", DB_FILE);
  } catch (err) {
    console.error("Error writing initial database file", err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON parsing middleware with high payload limit for signatures/PDFs
  app.use(express.json({ limit: "50mb" }));

  // API Route: Get State
  app.get("/api/state", (req, res) => {
    res.json(dbState);
  });

  // API Route: Sync/Update State
  app.post("/api/state", (req, res) => {
    try {
      const updates = req.body;
      if (updates) {
        // Merge updates selectively
        if (updates.patients) dbState.patients = updates.patients;
        if (updates.orders) dbState.orders = updates.orders;
        if (updates.exams) dbState.exams = updates.exams;
        if (updates.referenceRanges) dbState.referenceRanges = updates.referenceRanges;
        if (updates.results) dbState.results = updates.results;
        if (updates.auditLogs) dbState.auditLogs = updates.auditLogs;
        if (updates.users) dbState.users = updates.users;
        if (updates.letterhead) dbState.letterhead = updates.letterhead;

        // Save back to DB file
        fs.writeFileSync(DB_FILE, JSON.stringify(dbState, null, 2), "utf-8");
      }
      res.json(dbState);
    } catch (err) {
      console.error("Error updating database state:", err);
      res.status(500).json({ error: "Failed to update database state" });
    }
  });

  // Serve Vite app or compiled static assets
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
